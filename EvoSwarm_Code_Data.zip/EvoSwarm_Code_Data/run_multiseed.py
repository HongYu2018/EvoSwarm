from __future__ import annotations
import argparse
from pathlib import Path
import pandas as pd
from evoswarm.experiment import run_all


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--seeds", nargs="+", type=int, default=[7, 17, 27, 37, 47])
    p.add_argument("--episodes", type=int, default=30)
    p.add_argument("--steps", type=int, default=6)
    p.add_argument("--llm-mode", choices=["proxy", "live"], default="proxy")
    p.add_argument("--output-dir", default="outputs_multiseed")
    p.add_argument("--include-pure-l3", action="store_true")
    a = p.parse_args()

    root = Path(a.output_dir)
    root.mkdir(parents=True, exist_ok=True)
    all_summary, all_self = [], []

    for seed in a.seeds:
        _, _, summary, _, _, self_evo = run_all(
            a.episodes, a.steps, seed, a.llm_mode, root / f"seed_{seed}", a.include_pure_l3
        )
        summary["seed"] = seed
        all_summary.append(summary)
        if not self_evo.empty:
            self_evo["seed"] = seed
            all_self.append(self_evo)

    df = pd.concat(all_summary, ignore_index=True)
    df.to_csv(root / "per_seed_summary.csv", index=False)

    paper = (
        df.groupby("system")
        .agg(
            success_mean=("scenario_success_rate", "mean"),
            success_std=("scenario_success_rate", "std"),
            service_mean=("service_level", "mean"),
            service_std=("service_level", "std"),
            operational_score_mean=("mean_operational_score", "mean"),
            operational_score_std=("mean_operational_score", "std"),
            active_agents_mean=("active_agents", "mean"),
            agent_recall_mean=("agent_recall", "mean"),
            causal_coverage_mean=("causal_coverage", "mean"),
            resource_cost_mean=("resource_cost", "mean"),
            l3_calls_mean=("l3_calls", "mean"),
        )
        .reset_index()
    )
    paper.to_csv(root / "paper_summary_mean_std.csv", index=False)
    print(paper.to_string(index=False))

    if all_self:
        se = pd.concat(all_self, ignore_index=True)
        se.to_csv(root / "self_evolution_per_seed.csv", index=False)
        se_summary = (
            se.groupby("phase")
            .agg(
                experience_gain_mean=("experience_gain_operational_score", "mean"),
                experience_gain_std=("experience_gain_operational_score", "std"),
                resource_learning_gain_mean=("resource_learning_gain", "mean"),
                recall_gain_mean=("agent_recall_gain", "mean"),
                reuse_accuracy_mean=("swarm_reuse_accuracy", "mean"),
                regret_mean=("adaptation_regret", "mean"),
            )
            .reset_index()
        )
        se_summary.to_csv(root / "self_evolution_mean_std.csv", index=False)
        print("\nSelf-evolution across seeds")
        print(se_summary.to_string(index=False))

if __name__ == "__main__":
    main()
