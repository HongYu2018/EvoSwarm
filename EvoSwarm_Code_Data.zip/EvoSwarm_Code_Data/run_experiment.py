from __future__ import annotations
import argparse
from pathlib import Path
from evoswarm.experiment import run_all, SYSTEMS
from evoswarm.plots import create_plots


def main():
    p = argparse.ArgumentParser(description="EvoSwarm Supply-Chain V1.4")
    p.add_argument("--episodes", type=int, default=30)
    p.add_argument("--steps", type=int, default=6)
    p.add_argument("--seed", type=int, default=7)
    p.add_argument("--llm-mode", choices=["proxy", "live"], default="proxy")
    p.add_argument("--output-dir", default="outputs")
    p.add_argument("--include-pure-l3", action="store_true")
    p.add_argument("--systems", nargs="*", choices=SYSTEMS, default=None)
    a = p.parse_args()

    steps, eps, summary, scenario, phase, self_evo = run_all(
        a.episodes, a.steps, a.seed, a.llm_mode, Path(a.output_dir),
        a.include_pure_l3, a.systems
    )
    create_plots(summary, scenario, steps, Path(a.output_dir))
    print("\n=== EvoSwarm V1.4 completed ===")
    print(summary.to_string(index=False))
    if not self_evo.empty:
        print("\n=== Self-evolution: experienced vs cold joint swarm ===")
        print(self_evo.to_string(index=False))
    print("\nOutputs:", Path(a.output_dir).resolve())

if __name__ == "__main__":
    main()
