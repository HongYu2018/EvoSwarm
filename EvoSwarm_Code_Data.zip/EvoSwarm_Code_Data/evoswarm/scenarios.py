from __future__ import annotations
import random
from dataclasses import dataclass, field
from .core import SemanticEvent

BASE_FAMILIES = [
    "normal_replenishment",
    "supplier_disruption",
    "staff_capacity_shift",
    "promotion_capacity",
    "conflicting_supplier_transport",
    "false_alarm_then_shift",
    "time_critical_dispatch",
]

GENERALISATION_FAMILIES = [
    "compound_supplier_staff",
    "compound_demand_transport",
    "compound_multi_constraint",
]

SCENARIO_FAMILIES = BASE_FAMILIES + GENERALISATION_FAMILIES

# Frozen, nested evaluation manifest. A 10-episode run is exactly the first
# 10 cases of a 20/30/120-episode run with the same seed. This prevents the
# earlier problem where changing --episodes changed phase boundaries and tasks.
MANIFEST_VERSION = "v14-fixed-block10-r1"
MANIFEST_BLOCK_SIZE = 10
CHALLENGE_FAMILIES = [f for f in BASE_FAMILIES if f != "normal_replenishment"]

@dataclass
class StepChange:
    step: int
    updates: dict = field(default_factory=dict)
    events: list[SemanticEvent] = field(default_factory=list)
    latent_agent_bias: dict[str, float] = field(default_factory=dict)

@dataclass
class ScenarioDefinition:
    name: str
    variant: str
    phase: str
    demand_multiplier: float = 1.0
    urgent_multiplier: float = 1.0
    supplier_a_risk: float = 0.10
    supplier_b_risk: float = 0.16
    route_a_risk: float = 0.06
    route_b_risk: float = 0.09
    staff_loss: int = 0
    forklift_failure: bool = False
    transport_multiplier: float = 1.0
    decision_budget_units: float = 18.0
    initial_events: list[SemanticEvent] = field(default_factory=list)
    timeline: list[StepChange] = field(default_factory=list)
    causal_signature: tuple[str, ...] = field(default_factory=tuple)


def _manifest_spec(episode: int) -> tuple[str, str, int]:
    """Return (phase, scenario_family, variant_index) from a fixed manifest.

    Each 10-case block contains four experience cases (one normal + three
    rotating challenges), three causal recurrences of those challenge cases,
    and three compound generalisation cases. Because the mapping depends only
    on absolute episode number, the first N episodes are invariant to the final
    requested run length.
    """
    if episode < 1:
        raise ValueError("episode must be >= 1")

    block = (episode - 1) // MANIFEST_BLOCK_SIZE
    slot = (episode - 1) % MANIFEST_BLOCK_SIZE

    # Three rotating challenge families are first experienced, then recur in
    # altered surface form within the same block. Across blocks this rotates
    # through all challenge families while retaining a stable normal anchor.
    start = (block * 3) % len(CHALLENGE_FAMILIES)
    challenges = [CHALLENGE_FAMILIES[(start + i) % len(CHALLENGE_FAMILIES)] for i in range(3)]

    if slot == 0:
        return "experience", "normal_replenishment", episode
    if 1 <= slot <= 3:
        return "experience", challenges[slot - 1], episode
    if 4 <= slot <= 6:
        return "recurrence", challenges[slot - 4], episode

    # Compound families are also rotated, although all three occur per block.
    gstart = block % len(GENERALISATION_FAMILIES)
    compounds = [GENERALISATION_FAMILIES[(gstart + i) % len(GENERALISATION_FAMILIES)] for i in range(3)]
    return "generalisation", compounds[slot - 7], episode


def phase_for_episode(episode: int, total_episodes: int | None = None) -> str:
    # total_episodes is intentionally ignored for backward compatibility.
    return _manifest_spec(episode)[0]


def _event(kind, target, text, severity, confidence, source="operations_feed", expires=2):
    return SemanticEvent(kind, target, text, severity, confidence, expires, source, 0)


def make_scenario(name: str, phase: str, rng: random.Random, variant_index: int = 0) -> ScenarioDefinition:
    recurrent = phase == "recurrence"
    suffix = "analogue" if recurrent else ("novel_compound" if phase == "generalisation" else "base")
    variant = f"{name}_{suffix}_{variant_index % 4}"

    if name == "normal_replenishment":
        return ScenarioDefinition(
            name, variant, phase,
            demand_multiplier=rng.uniform(.96, 1.09),
            causal_signature=("demand", "inventory", "procurement"),
        )

    if name == "supplier_disruption":
        supplier = "supplier_B" if recurrent and variant_index % 2 else "supplier_A"
        text = (
            "A component quality hold is likely to delay Supplier B dispatches."
            if supplier == "supplier_B"
            else "Severe weather is disrupting Supplier A outbound logistics."
        )
        a_risk = rng.uniform(.31, .46) if supplier == "supplier_A" else rng.uniform(.10, .16)
        b_risk = rng.uniform(.30, .44) if supplier == "supplier_B" else rng.uniform(.15, .21)
        return ScenarioDefinition(
            name, variant, phase,
            demand_multiplier=rng.uniform(1.00, 1.12),
            urgent_multiplier=rng.uniform(1.15, 1.40),
            supplier_a_risk=a_risk,
            supplier_b_risk=b_risk,
            initial_events=[_event("supplier_disruption", supplier, text, .30, .90, "supplier_bulletin", 3)],
            timeline=[
                StepChange(3, updates={"supplier_a_risk": .12, "supplier_b_risk": .17},
                           events=[_event("supplier_recovery", supplier,
                                         "The affected supplier reports that dispatch reliability is recovering.",
                                         -.20, .86, "supplier_bulletin", 2)])
            ],
            causal_signature=("supplier_risk", "inventory", "procurement", "fulfilment"),
        )

    if name == "staff_capacity_shift":
        return ScenarioDefinition(
            name, variant, phase,
            urgent_multiplier=rng.uniform(1.12, 1.35),
            staff_loss=rng.choice([2, 3]),
            initial_events=[_event("absence_notice", "staffing",
                                   "Unexpected staff absence reduces warehouse shift coverage.", .28, .91,
                                   "workforce_feed", 2)],
            timeline=[
                StepChange(3, updates={"staff_available_delta": 2},
                           events=[_event("shift_recovery", "staffing",
                                         "Replacement staff become available for the later shift.", -.22, .90,
                                         "workforce_feed", 2)])
            ],
            causal_signature=("staff_shortage", "warehouse_constraint", "backlog", "fulfilment"),
        )

    if name == "promotion_capacity":
        # A1 is intentionally somewhat biased under promotions. This is hidden from
        # the World Model so contextual trust can learn from downstream outcomes.
        return ScenarioDefinition(
            name, variant, phase,
            demand_multiplier=rng.uniform(1.18, 1.33),
            urgent_multiplier=rng.uniform(1.22, 1.50),
            staff_loss=rng.choice([1, 2]),
            initial_events=[
                _event("promotion", "demand",
                       "A regional campaign is expected to increase short-term demand.", .25, .88,
                       "commercial_feed", 3),
                _event("capacity_notice", "staffing",
                       "Warehouse staffing is slightly below the planned level.", .16, .82,
                       "workforce_feed", 2),
            ],
            timeline=[StepChange(0, latent_agent_bias={"A1_Demand": -0.13})],
            causal_signature=("demand_pressure", "staff_shortage", "inventory", "warehouse_constraint"),
        )

    if name == "conflicting_supplier_transport":
        # Supplier B appears operationally attractive, but its route deteriorates.
        return ScenarioDefinition(
            name, variant, phase,
            supplier_a_risk=rng.uniform(.20, .28),
            supplier_b_risk=rng.uniform(.08, .13),
            route_a_risk=rng.uniform(.05, .09),
            route_b_risk=rng.uniform(.30, .44),
            urgent_multiplier=rng.uniform(1.18, 1.42),
            initial_events=[
                _event("supplier_capacity", "supplier_B",
                       "Supplier B confirms strong production availability.", -.12, .88,
                       "supplier_bulletin", 3),
                _event("route_disruption", "transport_B",
                       "A regional route restriction is disrupting deliveries from Supplier B.", .34, .93,
                       "transport_feed", 3),
            ],
            causal_signature=("supplier_risk", "transport_constraint", "procurement", "urgent_pressure"),
        )

    if name == "false_alarm_then_shift":
        # Surface evidence initially suggests supplier risk, but the true bottleneck
        # later becomes staffing. Always trusting every specialist can be harmful.
        target = "supplier_B" if recurrent else "supplier_A"
        return ScenarioDefinition(
            name, variant, phase,
            supplier_a_risk=.11,
            supplier_b_risk=.15,
            urgent_multiplier=rng.uniform(1.18, 1.35),
            initial_events=[_event("precautionary_warning", target,
                                   "A precautionary supplier warning has been issued; disruption is not yet confirmed.",
                                   .30, .58, "external_news", 2)],
            timeline=[
                StepChange(2,
                           events=[_event("warning_retracted", target,
                                         "The earlier supplier warning is withdrawn; operations are normal.",
                                         -.30, .94, "supplier_bulletin", 2)]),
                StepChange(3, updates={"staff_available_delta": -3},
                           events=[_event("absence_notice", "staffing",
                                         "Unexpected absence now constrains the active warehouse shift.",
                                         .30, .93, "workforce_feed", 2)])
            ],
            causal_signature=("evidence_conflict", "staff_shortage", "warehouse_constraint", "fulfilment"),
        )

    if name == "time_critical_dispatch":
        return ScenarioDefinition(
            name, variant, phase,
            demand_multiplier=rng.uniform(1.05, 1.16),
            urgent_multiplier=rng.uniform(1.45, 1.75),
            transport_multiplier=rng.uniform(.82, .94),
            decision_budget_units=rng.uniform(8.0, 9.2),
            initial_events=[_event("urgent_dispatch", "fulfilment",
                                   "A large set of priority customer orders must be dispatched within the current window.",
                                   .35, .96, "customer_ops", 2)],
            causal_signature=("urgent_pressure", "transport_constraint", "deadline_pressure", "fulfilment"),
        )

    if name == "compound_supplier_staff":
        return ScenarioDefinition(
            name, variant, phase,
            demand_multiplier=rng.uniform(1.10, 1.22),
            urgent_multiplier=rng.uniform(1.28, 1.55),
            supplier_a_risk=rng.uniform(.34, .47),
            staff_loss=rng.choice([2, 3]),
            initial_events=[
                _event("supplier_disruption", "supplier_A",
                       "Supplier A reports a manufacturing interruption with uncertain dispatch timing.", .34, .90,
                       "supplier_bulletin", 3),
                _event("absence_notice", "staffing",
                       "Warehouse staff absence reduces the current shift capacity.", .28, .91,
                       "workforce_feed", 2),
            ],
            causal_signature=("supplier_risk", "staff_shortage", "inventory", "warehouse_constraint", "fulfilment"),
        )

    if name == "compound_demand_transport":
        return ScenarioDefinition(
            name, variant, phase,
            demand_multiplier=rng.uniform(1.24, 1.38),
            urgent_multiplier=rng.uniform(1.32, 1.62),
            route_b_risk=rng.uniform(.28, .42),
            transport_multiplier=rng.uniform(.73, .88),
            initial_events=[
                _event("promotion", "demand",
                       "Demand is accelerating after a national promotional campaign.", .31, .91,
                       "commercial_feed", 3),
                _event("route_disruption", "transport_B",
                       "A transport bottleneck affects one of the main inbound and outbound corridors.", .30, .89,
                       "transport_feed", 3),
            ],
            timeline=[StepChange(0, latent_agent_bias={"A1_Demand": -0.12})],
            causal_signature=("demand_pressure", "transport_constraint", "inventory", "urgent_pressure", "fulfilment"),
        )

    if name == "compound_multi_constraint":
        return ScenarioDefinition(
            name, variant, phase,
            demand_multiplier=rng.uniform(1.20, 1.35),
            urgent_multiplier=rng.uniform(1.35, 1.68),
            supplier_a_risk=rng.uniform(.30, .43),
            staff_loss=rng.choice([2, 3]),
            forklift_failure=rng.random() < .65,
            transport_multiplier=rng.uniform(.74, .90),
            decision_budget_units=rng.uniform(10.0, 11.5),
            initial_events=[
                _event("promotion", "demand", "Demand has risen sharply above the normal operating range.", .30, .90, "commercial_feed", 3),
                _event("supplier_disruption", "supplier_A", "Supplier A has uncertain lead times after a production problem.", .31, .89, "supplier_bulletin", 3),
                _event("absence_notice", "staffing", "Warehouse staffing is below the planned shift level.", .25, .90, "workforce_feed", 2),
            ] + ([_event("equipment_failure", "warehouse", "The primary forklift is unavailable.", .34, .96, "maintenance_feed", 3)] if rng.random() < .65 else []),
            timeline=[StepChange(0, latent_agent_bias={"A1_Demand": -0.10, "A2_Supplier": -0.08})],
            causal_signature=("demand_pressure", "supplier_risk", "staff_shortage", "warehouse_constraint", "transport_constraint", "urgent_pressure"),
        )

    raise ValueError(name)


def choose_scenario(episode: int, total_episodes: int, rng: random.Random) -> ScenarioDefinition:
    # total_episodes is intentionally not used: the fixed manifest guarantees
    # nested evaluation sets (10 is the prefix of 20, 30, 120, ...).
    phase, name, variant_index = _manifest_spec(episode)
    return make_scenario(name, phase, rng, variant_index)

