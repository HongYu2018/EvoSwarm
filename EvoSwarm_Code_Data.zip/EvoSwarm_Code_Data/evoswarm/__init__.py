"""EvoSwarm Supply-Chain V1.4: causal, experience-guided minimum-sufficient swarms."""
__version__ = "1.4"
