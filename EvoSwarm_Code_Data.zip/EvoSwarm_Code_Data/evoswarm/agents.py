from __future__ import annotations
import json
import math
import time
import urllib.request
from .core import AgentMessage, ActionPlan
from .world_model import WorldModel
from .shell import CognitiveShell
from .config import Settings


def _trust(trust_scores, agent):
    if not trust_scores:
        return 1.0
    return float(max(.05, min(.98, trust_scores.get(agent, .72))))


def _blend(observed, baseline, trust):
    return trust * float(observed) + (1.0 - trust) * float(baseline)


def _msg(agent, conf, evidence, proposal, requests, sr, bias=0.0):
    # Hidden reliability shifts make static all-agent systems vulnerable to stale
    # or regime-specific specialist failure. Confidence only partially reflects it.
    conf = max(.35, conf * (1.0 - min(.30, abs(float(bias)) * .9)))
    return AgentMessage(
        agent=agent,
        confidence=conf,
        evidence=evidence,
        proposal=proposal,
        requests=requests,
        shell_used=sr.used,
        shell_input_tokens=sr.input_tokens,
        shell_output_tokens=sr.output_tokens,
        shell_latency_ms=sr.latency_ms,
        shell_fallback=sr.fallback,
    )


def run_l1_agent(agent: str, wm: WorldModel, shell: CognitiveShell, bus: dict, trust_scores=None) -> AgentMessage:
    v = wm.view_for(agent)
    sr = shell.interpret(agent, v)
    s = wm.state
    adj = sr.adjustments
    bias = float(s.latent_agent_bias.get(agent, 0.0))

    if agent == "A1_Demand":
        forecast = max(20.0, s.demand_forecast * adj.get("demand_multiplier", 1.0) * (1.0 + bias))
        req = ["A3_Inventory"] if forecast + s.backlog > s.inventory + sum(x.qty for x in s.incoming) else []
        return _msg(agent, .84, {"forecast": forecast, "used_agents": []}, {}, req, sr, bias)

    if agent == "A2_Supplier":
        ra = max(.01, min(.95, s.supplier_a_risk + adj.get("supplier_a_risk_delta", 0.0) + bias))
        rb = max(.01, min(.95, s.supplier_b_risk + adj.get("supplier_b_risk_delta", 0.0) + bias))
        req = ["A6_Procurement"] if min(ra, rb) > .22 else []
        return _msg(agent, .86, {"risk_A": ra, "risk_B": rb, "used_agents": []}, {}, req, sr, bias)

    if agent == "A3_Inventory":
        d = bus.get("A1_Demand")
        if d:
            td = _trust(trust_scores, "A1_Demand")
            observed = d.evidence.get("forecast", s.demand_forecast)
            forecast = _blend(observed, s.demand_forecast, td)
        else:
            forecast = s.demand_forecast
        inbound = sum(x.qty for x in s.incoming if not x.delayed)
        need = forecast + .70 * s.backlog + .85 * s.urgent_backlog
        coverage = (s.inventory + .62 * inbound) / max(need, 1)
        risk = 1 / (1 + math.exp(4.0 * (coverage - 1)))
        req = []
        if risk > .46:
            req.append("A6_Procurement")
        if not d and "demand_pressure" in wm.features():
            req.append("A1_Demand")
        return _msg(agent, .88, {"stockout_risk": risk, "coverage": coverage, "used_agents": ["A1_Demand"] if d else []}, {}, req, sr, bias)

    if agent == "A4_Warehouse":
        mult = adj.get("warehouse_capacity_multiplier", 1.0)
        cap = s.staff_available * s.throughput_per_worker * (1 if s.forklift_available else .62) * mult * (1.0 + bias)
        ratio = cap / max(s.current_demand + s.backlog, 1)
        req = ["A5_Staffing"] if ratio < .92 else []
        return _msg(agent, .89, {"capacity": cap, "capacity_ratio": ratio, "used_agents": []}, {"rent_forklift": bool(not s.forklift_available and ratio < .86)}, req, sr, bias)

    if agent == "A5_Staffing":
        effective_staff = max(0, int(round(s.staff_available + adj.get("staff_delta", 0))))
        wh = bus.get("A4_Warehouse")
        wh_ratio = float(wh.evidence.get("capacity_ratio", 1)) if wh else 1.0
        needed = math.ceil((s.current_demand + s.backlog) / max(s.throughput_per_worker, 1))
        overtime = max(0, min(5, needed - effective_staff))
        req = ["A4_Warehouse"] if overtime > 0 and not wh else []
        return _msg(agent, .87, {"effective_staff": effective_staff, "needed_staff": needed, "warehouse_ratio": wh_ratio, "used_agents": ["A4_Warehouse"] if wh else []}, {"overtime_workers": overtime}, req, sr, bias)

    if agent == "A8_Transport":
        route_a = max(.01, min(.95, s.route_a_risk + adj.get("route_a_risk_delta", 0.0) + bias))
        route_b = max(.01, min(.95, s.route_b_risk + adj.get("route_b_risk_delta", 0.0) + bias))
        effective = s.transport_capacity * adj.get("transport_capacity_multiplier", 1.0) * (1.0 + bias)
        need = s.backlog + s.current_demand
        urgent_pressure = (s.urgent_backlog + s.current_urgent_demand) / max(need, 1)
        expedite = effective < .84 * need or urgent_pressure > .20
        req = ["A7_Fulfilment"] if urgent_pressure > .22 else []
        return _msg(agent, .88, {"effective_transport_capacity": effective, "route_risk_A": route_a, "route_risk_B": route_b, "urgent_pressure": urgent_pressure, "used_agents": []}, {"expedite_transport": expedite}, req, sr, bias)

    if agent == "A6_Procurement":
        d = bus.get("A1_Demand")
        sp = bus.get("A2_Supplier")
        inv = bus.get("A3_Inventory")
        tr = bus.get("A8_Transport")

        if d:
            forecast = _blend(d.evidence.get("forecast", s.demand_forecast), s.demand_forecast, _trust(trust_scores, "A1_Demand"))
        else:
            forecast = s.demand_forecast
        if sp:
            ra = _blend(sp.evidence.get("risk_A", s.supplier_a_risk), s.supplier_a_risk, _trust(trust_scores, "A2_Supplier"))
            rb = _blend(sp.evidence.get("risk_B", s.supplier_b_risk), s.supplier_b_risk, _trust(trust_scores, "A2_Supplier"))
        else:
            ra, rb = s.supplier_a_risk, s.supplier_b_risk
        if tr:
            rta = _blend(tr.evidence.get("route_risk_A", s.route_a_risk), s.route_a_risk, _trust(trust_scores, "A8_Transport"))
            rtb = _blend(tr.evidence.get("route_risk_B", s.route_b_risk), s.route_b_risk, _trust(trust_scores, "A8_Transport"))
        else:
            rta, rtb = s.route_a_risk, s.route_b_risk

        inbound = sum(x.qty for x in s.incoming)
        risk_buffer = .20 if (inv and inv.evidence.get("stockout_risk", 0) > .55) else .05
        target = (1.85 + risk_buffer) * forecast + .72 * s.backlog
        qty = max(0, round(target - s.inventory - .62 * inbound))
        score_a = ra + .50 * rta + .03 * s.supplier_a_lead
        score_b = rb + .50 * rtb + .03 * s.supplier_b_lead + .07
        supplier = "A" if score_a <= score_b else "B"
        used = [x for x in ["A1_Demand", "A2_Supplier", "A3_Inventory", "A8_Transport"] if x in bus]
        req = []
        if not d and ("demand_pressure" in wm.features() or "regime_shift" in wm.features()):
            req.append("A1_Demand")
        if not sp and ("supplier_risk" in wm.features() or "evidence_conflict" in wm.features()):
            req.append("A2_Supplier")
        if not tr and "transport_constraint" in wm.features():
            req.append("A8_Transport")
        if not inv and "inventory_risk" in wm.causal_closure():
            req.append("A3_Inventory")
        return _msg(agent, .88, {"target_stock": target, "supplier_score_A": score_a, "supplier_score_B": score_b, "used_agents": used}, {"order_qty": qty, "supplier": supplier}, req, sr, bias)

    if agent == "A7_Fulfilment":
        inv = bus.get("A3_Inventory")
        wh = bus.get("A4_Warehouse")
        tr = bus.get("A8_Transport")
        urgent_pressure = (s.urgent_backlog + s.current_urgent_demand) / max(s.current_demand + s.backlog, 1)
        priority = min(.96, max(.55, .58 + 1.55 * urgent_pressure + adj.get("urgent_priority_delta", 0.0)))
        if inv and inv.evidence.get("stockout_risk", 0) > .60:
            priority = max(priority, .86)
        if wh and wh.evidence.get("capacity_ratio", 1) < .80:
            priority = max(priority, .90)
        if tr and tr.evidence.get("effective_transport_capacity", s.transport_capacity) < .80 * (s.current_demand + s.backlog):
            priority = max(priority, .91)
        req = []
        if not tr and ("urgent_pressure" in wm.features() or "deadline_pressure" in wm.features()):
            req.append("A8_Transport")
        if not wh and "warehouse_constraint" in wm.causal_closure():
            req.append("A4_Warehouse")
        if not inv and "inventory_risk" in wm.causal_closure():
            req.append("A3_Inventory")
        used = [x for x in ["A3_Inventory", "A4_Warehouse", "A5_Staffing", "A8_Transport"] if x in bus]
        return _msg(agent, .90, {"urgent_pressure": urgent_pressure, "used_agents": used}, {"urgent_priority": priority}, req, sr, bias)

    raise ValueError(agent)


def assemble_plan(messages, trust_scores=None):
    p = ActionPlan()
    conf = []
    # Proposal ownership is mostly specialised, so trust acts as a guard rather
    # than averaging incompatible proposals. Low-trust proposals are retained only
    # when no safer specialist proposal exists.
    for m in messages:
        t = _trust(trust_scores, m.agent)
        conf.append(m.confidence * t)
        q = m.proposal
        if t < .34 and m.agent not in {"A7_Fulfilment"}:
            continue
        for k in ["order_qty", "supplier", "overtime_workers", "urgent_priority", "expedite_transport", "rent_forklift"]:
            if k in q:
                setattr(p, k, q[k])
    p.confidence = min(conf) if conf else .5
    p.rationale = "assembled from specialist proposals with contextual trust"
    return p.clamp()


PLAN_SCHEMA = {
    "type": "object",
    "properties": {
        "order_qty": {"type": "integer"},
        "supplier": {"type": "string", "enum": ["A", "B"]},
        "overtime_workers": {"type": "integer"},
        "urgent_priority": {"type": "number"},
        "expedite_transport": {"type": "boolean"},
        "rent_forklift": {"type": "boolean"},
        "confidence": {"type": "number"},
        "rationale": {"type": "string"},
    },
    "required": ["order_qty", "supplier", "overtime_workers", "urgent_priority", "expedite_transport", "rent_forklift", "confidence", "rationale"],
    "additionalProperties": False,
}

class LocalGeneralReasoner:
    def __init__(self, mode="proxy", settings=None):
        self.mode = mode
        self.settings = settings or Settings()

    def refine(self, wm, messages, plan):
        if self.mode != "live":
            f = set(wm.features())
            if "staff_shortage" in f or "warehouse_constraint" in f:
                plan.overtime_workers = max(plan.overtime_workers, 1)
            if "urgent_pressure" in f or "deadline_pressure" in f:
                plan.urgent_priority = max(plan.urgent_priority, .84)
            if "transport_constraint" in f:
                plan.expedite_transport = True
            return plan.clamp(), {"backend": "proxy_l2", "input_tokens": 0, "output_tokens": 0, "latency_ms": 0., "fallback": False}
        return _ollama_plan(self.settings, _refine_prompt(wm, messages, plan, False), plan)

class FrontierCritic:
    """L3 critiques the specialist plan rather than automatically replacing it."""
    def __init__(self, mode="proxy", settings=None):
        self.mode = mode
        self.settings = settings or Settings()

    def refine(self, wm, messages, plan):
        if self.mode != "live":
            f = set(wm.features())
            if {"supplier_risk", "inventory_risk"} <= f:
                plan.order_qty = int(plan.order_qty * 1.07)
            if "urgent_pressure" in f:
                plan.urgent_priority = max(plan.urgent_priority, .89)
            return plan.clamp(), {"backend": "proxy_l3_critic", "input_tokens": 0, "output_tokens": 0, "latency_ms": 0., "fallback": False}
        return _openai_plan(self.settings, self.settings.openai_l3_model, _refine_prompt(wm, messages, plan, True), plan, "evoswarm_critic_plan")

class PureL2Planner:
    """Pure local-generalist baseline.

    No specialist agents, no cognitive shells, no learned topology. The complete
    World Model is sent directly to the configured Ollama model, which makes the
    operational decision for the current step.

    Proxy mode uses a deterministic heuristic only for software/architecture
    validation; only live mode measures the real local LLM.
    """
    def __init__(self, mode="proxy", settings=None):
        self.mode = mode
        self.settings = settings or Settings()

    def plan(self, wm):
        if self.mode != "live":
            s = wm.state
            inbound = sum(x.qty for x in s.incoming)
            target = 1.78 * s.demand_forecast + .68 * s.backlog
            qty = max(0, int(round(target - s.inventory - .60 * inbound)))
            sa = s.supplier_a_risk + .45 * s.route_a_risk + .04 * s.supplier_a_lead
            sb = s.supplier_b_risk + .45 * s.route_b_risk + .04 * s.supplier_b_lead + .07
            supplier = "A" if sa <= sb else "B"
            workers = max(0, min(5, math.ceil((s.current_demand + s.backlog) / max(s.throughput_per_worker, 1.0)) - s.staff_available))
            p = ActionPlan(
                qty,
                supplier,
                workers,
                .86 if "urgent_pressure" in wm.features() else .70,
                "transport_constraint" in wm.features(),
                "warehouse_constraint" in wm.features() and not s.forklift_available,
                .82,
                "pure L2 proxy",
            ).clamp()
            return p, {
                "backend": "proxy_pure_l2",
                "input_tokens": 0,
                "output_tokens": 0,
                "latency_ms": 0.0,
                "fallback": False,
            }

        prompt = f'''You are the ONLY decision-making AI for a multi-step warehouse and supply-chain environment.
There are no specialist agents and no frontier model. Read the complete World Model, including history,
causal rules, delayed inbound inventory, uncertainty, route risk, staffing, warehouse capacity and
current decision deadline. Choose the operational action for the CURRENT step and account for downstream consequences.

WORLD MODEL:
{json.dumps(wm.full_view(), indent=2)}

Return the complete action plan. Every operational field must be explicitly chosen for the current state.
Do not omit fields and do not use a default/no-op plan unless the World Model actually justifies it.'''
        return _ollama_plan(self.settings, prompt, ActionPlan())


class PureL3Planner:
    def __init__(self, mode="proxy", settings=None):
        self.mode = mode
        self.settings = settings or Settings()

    def plan(self, wm):
        if self.mode != "live":
            s = wm.state
            inbound = sum(x.qty for x in s.incoming)
            target = 1.92 * s.demand_forecast + .72 * s.backlog
            qty = max(0, int(round(target - s.inventory - .58 * inbound)))
            sa = s.supplier_a_risk + .5 * s.route_a_risk + .04 * s.supplier_a_lead
            sb = s.supplier_b_risk + .5 * s.route_b_risk + .04 * s.supplier_b_lead + .07
            supplier = "A" if sa <= sb else "B"
            workers = max(0, min(5, math.ceil((s.current_demand + s.backlog) / s.throughput_per_worker) - s.staff_available))
            p = ActionPlan(qty, supplier, workers, .89 if "urgent_pressure" in wm.features() else .72,
                           "transport_constraint" in wm.features(),
                           "warehouse_constraint" in wm.features() and not s.forklift_available,
                           .90, "pure L3 proxy").clamp()
            return p, {"backend": "proxy_pure_l3", "input_tokens": 0, "output_tokens": 0, "latency_ms": 0., "fallback": False}
        prompt = f'''You are the ONLY decision-making AI for a multi-step warehouse and supply-chain environment.
There are no specialist agents. Read the complete World Model, including history, causal rules,
delayed inbound inventory, uncertainty, route risk, staffing, warehouse capacity and decision deadlines.
Choose the operational action for the CURRENT step and account for downstream consequences.

WORLD MODEL:
{json.dumps(wm.full_view(), indent=2)}

Return the complete action plan.'''
        return _openai_plan(self.settings, self.settings.pure_l3_model, prompt, ActionPlan(), "pure_l3_action_plan")


def _refine_prompt(wm, messages, plan, critic):
    role = (
        "You are a frontier critic. Preserve bounded specialist decisions unless causal evidence, conflict or downstream risk justifies a change."
        if critic else
        "You are a local general reasoning agent. Resolve conflicts among specialist evidence and consider downstream temporal consequences."
    )
    ms = [{"agent": m.agent, "evidence": m.evidence, "proposal": m.proposal, "confidence": m.confidence} for m in messages]
    return f'''{role}
WORLD MODEL:
{json.dumps(wm.full_view(), indent=2)}
SPECIALIST MESSAGES:
{json.dumps(ms, indent=2)}
CURRENT PLAN:
{json.dumps(plan.__dict__, indent=2)}
Return a complete revised action plan.'''


_ACTION_FIELDS = [
    "order_qty", "supplier", "overtime_workers", "urgent_priority",
    "expedite_transport", "rent_forklift", "confidence", "rationale",
]
_ACTION_ALIASES = {
    "order_quantity": "order_qty",
    "order": "order_qty",
    "quantity": "order_qty",
    "supplier_choice": "supplier",
    "chosen_supplier": "supplier",
    "overtime": "overtime_workers",
    "overtime_staff": "overtime_workers",
    "priority": "urgent_priority",
    "urgent_order_priority": "urgent_priority",
    "expedite": "expedite_transport",
    "expedite_delivery": "expedite_transport",
    "forklift_rental": "rent_forklift",
    "hire_forklift": "rent_forklift",
    "reason": "rationale",
    "explanation": "rationale",
}


def _extract_json_object(text):
    """Parse JSON robustly without silently accepting missing action fields."""
    if isinstance(text, dict):
        return text
    if text is None:
        raise ValueError("empty Ollama response")
    raw = str(text).strip()
    if not raw:
        raise ValueError("empty Ollama response")
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        pass
    # Models sometimes wrap JSON in markdown fences or explanatory text.
    if "```" in raw:
        for part in raw.split("```"):
            candidate = part.strip()
            if candidate.lower().startswith("json"):
                candidate = candidate[4:].strip()
            if candidate.startswith("{"):
                try:
                    return json.loads(candidate)
                except json.JSONDecodeError:
                    pass
    start, end = raw.find("{"), raw.rfind("}")
    if start >= 0 and end > start:
        return json.loads(raw[start:end + 1])
    raise ValueError("no JSON object found in Ollama response")


def _find_action_dict(obj):
    """Unwrap common wrappers such as {action_plan:{...}} and find action fields."""
    if not isinstance(obj, dict):
        raise ValueError("Ollama JSON is not an object")

    # Normalise aliases at the current level first.
    normalised = {}
    for k, v in obj.items():
        key = _ACTION_ALIASES.get(str(k).strip().lower(), str(k).strip())
        normalised[key] = v
    present = set(normalised) & set(_ACTION_FIELDS)
    if len(present) >= 4 or {"order_qty", "supplier"} <= present:
        return normalised

    # Common wrappers produced by local models.
    for key in ["action_plan", "action", "plan", "decision", "response", "result", "output"]:
        child = obj.get(key)
        if isinstance(child, dict):
            try:
                return _find_action_dict(child)
            except ValueError:
                pass

    # Last resort: recursively inspect nested dictionaries.
    for child in obj.values():
        if isinstance(child, dict):
            try:
                return _find_action_dict(child)
            except ValueError:
                pass
    raise ValueError("JSON did not contain a recognisable action plan")


def _as_bool(v):
    if isinstance(v, bool):
        return v
    if isinstance(v, (int, float)):
        return bool(v)
    s = str(v).strip().lower()
    if s in {"true", "yes", "1", "y", "on"}:
        return True
    if s in {"false", "no", "0", "n", "off", "none", "null", ""}:
        return False
    raise ValueError(f"cannot coerce boolean value {v!r}")


def _action_from_dict(d):
    """Validate/coerce a model action. Missing operational fields are an error."""
    required_ops = {
        "order_qty", "supplier", "overtime_workers", "urgent_priority",
        "expedite_transport", "rent_forklift",
    }
    missing = sorted(required_ops - set(d))
    if missing:
        raise ValueError("missing required action fields: " + ", ".join(missing))

    supplier = str(d["supplier"]).strip().upper()
    if supplier not in {"A", "B"}:
        # tolerate strings such as "Supplier B"
        if supplier.endswith("A"):
            supplier = "A"
        elif supplier.endswith("B"):
            supplier = "B"
        else:
            raise ValueError(f"invalid supplier {d['supplier']!r}")

    p = ActionPlan(
        order_qty=int(round(float(d["order_qty"]))),
        supplier=supplier,
        overtime_workers=int(round(float(d["overtime_workers"]))),
        urgent_priority=float(d["urgent_priority"]),
        expedite_transport=_as_bool(d["expedite_transport"]),
        rent_forklift=_as_bool(d["rent_forklift"]),
        confidence=float(d.get("confidence", .70)),
        rationale=str(d.get("rationale", "Ollama action plan")),
    ).clamp()
    return p


def _ollama_request(settings, prompt, format_value):
    payload = {
        "model": settings.ollama_model,
        "prompt": prompt,
        "stream": False,
        "format": format_value,
        "options": {"temperature": 0.0},
    }
    req = urllib.request.Request(
        settings.ollama_url,
        data=json.dumps(payload).encode(),
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    st = time.perf_counter()
    with urllib.request.urlopen(req, timeout=120) as r:
        res = json.loads(r.read().decode())
    lat = (time.perf_counter() - st) * 1000
    return res, lat


def _ollama_plan(settings, prompt, fallback):
    """Get a validated action plan from Ollama.

    V1.4 hotfix:
    * requests a JSON-schema structured output where supported;
    * unwraps common nested JSON forms and aliases;
    * refuses to silently fill missing operational fields with fallback defaults;
    * retries once in ordinary JSON mode for older Ollama builds;
    * counts tokens/latency spent on failed/retried attempts;
    * marks a genuine fallback so the evaluation can detect baseline failures.
    """
    schema_prompt = prompt + """

Return ONLY one complete action-plan JSON object. All six operational fields are mandatory:
order_qty, supplier, overtime_workers, urgent_priority, expedite_transport, rent_forklift.
Also include confidence and rationale. Do not wrap the object in action_plan, result, response or markdown.
"""
    total_in = total_out = 0
    total_lat = 0.0
    errors = []

    # First attempt: native Ollama structured output using the same schema as L3.
    attempts = [
        (PLAN_SCHEMA, schema_prompt),
        ("json", schema_prompt + "\nPrevious output may have been invalid; strictly follow the requested top-level keys."),
    ]
    for idx, (fmt, ptxt) in enumerate(attempts, start=1):
        try:
            res, lat = _ollama_request(settings, ptxt, fmt)
            total_lat += lat
            total_in += int(res.get("prompt_eval_count", 0) or 0)
            total_out += int(res.get("eval_count", 0) or 0)
            raw = res.get("response", "")
            obj = _extract_json_object(raw)
            action_dict = _find_action_dict(obj)
            plan = _action_from_dict(action_dict)
            return plan, {
                "backend": "ollama_l2" if idx == 1 else "ollama_l2_retry",
                "input_tokens": total_in,
                "output_tokens": total_out,
                "latency_ms": total_lat,
                "fallback": False,
                "retry_count": idx - 1,
            }
        except Exception as e:
            errors.append(f"attempt {idx}: {type(e).__name__}: {e}")

    return fallback, {
        "backend": "ollama_l2_fallback",
        "input_tokens": total_in,
        "output_tokens": total_out,
        "latency_ms": total_lat,
        "fallback": True,
        "retry_count": 1,
        "error": " | ".join(errors)[:600],
    }

def _openai_plan(settings, model, prompt, fallback, schema_name):
    if not settings.openai_api_key:
        raise RuntimeError("OPENAI_API_KEY is missing from .env")
    from openai import OpenAI
    client = OpenAI(api_key=settings.openai_api_key)
    try:
        st = time.perf_counter()
        r = client.responses.create(
            model=model,
            input=[
                {"role": "system", "content": "Return a valid JSON action plan matching the supplied schema. Do not add extra fields."},
                {"role": "user", "content": prompt},
            ],
            text={"format": {"type": "json_schema", "name": schema_name, "strict": True, "schema": PLAN_SCHEMA}},
            store=False,
        )
        lat = (time.perf_counter() - st) * 1000
        d = json.loads(r.output_text)
        p = ActionPlan(**d).clamp()
        u = getattr(r, "usage", None)
        return p, {
            "backend": f"openai:{model}",
            "input_tokens": int(getattr(u, "input_tokens", 0) or 0) if u else 0,
            "output_tokens": int(getattr(u, "output_tokens", 0) or 0) if u else 0,
            "latency_ms": lat,
            "fallback": False,
        }
    except Exception as e:
        return fallback, {"backend": f"openai_fallback:{model}", "input_tokens": 0, "output_tokens": 0, "latency_ms": 0., "fallback": True, "error": str(e)[:300]}
