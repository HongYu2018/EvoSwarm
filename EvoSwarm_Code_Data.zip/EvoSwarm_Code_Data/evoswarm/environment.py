from __future__ import annotations
import math
import random
from .core import WorldState, ActionPlan, InboundOrder
from .scenarios import ScenarioDefinition

class SupplyChainEnvironment:
    """Multi-step causal operating environment with evolving conditions."""

    def __init__(self, scenario: ScenarioDefinition, episode: int, steps: int, seed: int):
        self.rng = random.Random(seed)
        self.scenario = scenario
        self.episode = episode
        self.steps = steps
        self._applied_changes: set[int] = set()
        self.state = WorldState(
            episode=episode,
            step=0,
            phase=scenario.phase,
            scenario=scenario.name,
            scenario_variant=scenario.variant,
            inventory=self.rng.uniform(112, 142),
            backlog=self.rng.uniform(8, 20),
            urgent_backlog=self.rng.uniform(1, 5),
            current_demand=0.0,
            current_urgent_demand=0.0,
            demand_forecast=96.0,
            supplier_a_risk=scenario.supplier_a_risk,
            supplier_b_risk=scenario.supplier_b_risk,
            supplier_a_lead=2,
            supplier_b_lead=1,
            route_a_risk=scenario.route_a_risk,
            route_b_risk=scenario.route_b_risk,
            staff_available=max(2, 7 - scenario.staff_loss),
            base_staff=7,
            throughput_per_worker=15.0,
            forklift_available=not scenario.forklift_failure,
            transport_capacity=112.0 * scenario.transport_multiplier,
            decision_budget_units=scenario.decision_budget_units,
            incoming=[],
            semantic_events=list(scenario.initial_events),
            history=[],
            latent_agent_bias={},
        )
        self.cumulative = {
            "demand": 0.0,
            "fulfilled": 0.0,
            "urgent_demand": 0.0,
            "urgent_fulfilled": 0.0,
            "operational_cost": 0.0,
            "stockout_steps": 0,
            "deadline_misses": 0,
            "constraint_violations": 0,
        }

    def _demand_for_step(self, step: int) -> tuple[float, float]:
        seasonal = 1.0 + .05 * math.sin((self.episode + step) / 3.2)
        base = 92.0 * self.scenario.demand_multiplier * seasonal
        demand = max(38.0, base + self.rng.gauss(0, 7.0))
        urgent = max(0.0, .12 * demand * self.scenario.urgent_multiplier + self.rng.gauss(0, 2.0))
        return demand, min(urgent, demand)

    def _apply_timeline(self, step: int):
        if step in self._applied_changes:
            return
        for change in self.scenario.timeline:
            if change.step != step:
                continue
            for key, value in change.updates.items():
                if key == "staff_available_delta":
                    self.state.staff_available = max(1, min(12, self.state.staff_available + int(value)))
                elif hasattr(self.state, key):
                    setattr(self.state, key, value)
            self.state.semantic_events.extend(change.events)
            self.state.latent_agent_bias.update(change.latent_agent_bias)
        self._applied_changes.add(step)

    def observe(self, step: int) -> WorldState:
        s = self.state
        s.step = step
        self._apply_timeline(step)

        demand, urgent = self._demand_for_step(step)
        s.current_demand = demand
        s.current_urgent_demand = urgent
        recent = [h["demand"] for h in s.history[-3:]]
        s.demand_forecast = (.62 * sum(recent) / len(recent) + .38 * demand) if recent else demand

        new_events = []
        for e in s.semantic_events:
            if e.expires_in > 0:
                new_events.append(e)
                e.expires_in -= 1
                e.age += 1
        s.semantic_events = new_events
        return s

    def _receive_inbound(self, step: int):
        s = self.state
        remaining = []
        for order in s.incoming:
            if order.arrival_step <= step:
                if not order.delayed:
                    s.inventory += order.qty
                else:
                    order.arrival_step += 1
                    order.delayed = False
                    remaining.append(order)
            else:
                remaining.append(order)
        s.incoming = remaining

    def step(self, action: ActionPlan, decision_units: float = 0.0) -> dict:
        s = self.state
        action.clamp()
        self._receive_inbound(s.step)

        supplier_risk = s.supplier_a_risk if action.supplier == "A" else s.supplier_b_risk
        route_risk = s.route_a_risk if action.supplier == "A" else s.route_b_risk
        lead = s.supplier_a_lead if action.supplier == "A" else s.supplier_b_lead
        delayed = self.rng.random() < min(.95, supplier_risk + .55 * route_risk)
        if action.order_qty > 0:
            s.incoming.append(InboundOrder(action.supplier, float(action.order_qty), s.step + lead, delayed))

        scheduled_staff = min(s.staff_available + action.overtime_workers, s.base_staff + 5)
        forklift_factor = 1.0 if (s.forklift_available or action.rent_forklift) else .62
        warehouse_capacity = scheduled_staff * s.throughput_per_worker * forklift_factor

        transport_capacity = s.transport_capacity * (1.35 if action.expedite_transport else 1.0)

        # Time-critical scenarios make overly expensive decision processes slightly
        # reduce the remaining execution window. This is deliberately bounded so
        # it cannot dominate the operational metrics.
        over_budget = max(0.0, decision_units - s.decision_budget_units)
        decision_delay_factor = max(.78, 1.0 - .035 * over_budget)
        deadline_met = int(over_budget <= .01)
        if not deadline_met:
            self.cumulative["deadline_misses"] += 1

        process_capacity = min(warehouse_capacity, transport_capacity) * decision_delay_factor
        normal_need = s.backlog + max(0.0, s.current_demand - s.current_urgent_demand)
        urgent_need = s.urgent_backlog + s.current_urgent_demand
        available = min(s.inventory, process_capacity)

        urgent_alloc = min(urgent_need, available * action.urgent_priority + .32 * available)
        remaining = max(0.0, available - urgent_alloc)
        normal_alloc = min(normal_need, remaining)
        fulfilled = urgent_alloc + normal_alloc

        previous_backlog = s.backlog
        s.inventory = max(0.0, s.inventory - fulfilled)
        s.urgent_backlog = max(0.0, urgent_need - urgent_alloc)
        s.backlog = max(0.0, normal_need - normal_alloc)

        unit_cost = 1.0 if action.supplier == "A" else 1.15
        purchase_cost = action.order_qty * unit_cost
        overtime_cost = action.overtime_workers * 18.0
        expedite_cost = 45.0 if action.expedite_transport else 0.0
        forklift_cost = 55.0 if action.rent_forklift else 0.0
        holding_cost = s.inventory * .07
        backlog_cost = s.backlog * .72 + s.urgent_backlog * 2.35
        op_cost = purchase_cost + overtime_cost + expedite_cost + forklift_cost + holding_cost + backlog_cost

        service_den = max(s.current_demand + previous_backlog, 1.0)
        service_level = max(0.0, min(1.0, fulfilled / service_den))
        urgent_service = urgent_alloc / max(urgent_need, 1.0)
        if s.inventory <= .01:
            self.cumulative["stockout_steps"] += 1

        cost_norm = min(1.0, op_cost / 470.0)
        backlog_norm = min(1.0, (s.backlog + 1.7 * s.urgent_backlog) / 150.0)
        operational_score = 100.0 * (
            .40 * service_level
            + .27 * urgent_service
            + .20 * (1.0 - backlog_norm)
            + .10 * (1.0 - cost_norm)
            + .03 * deadline_met
        )

        self.cumulative["demand"] += s.current_demand
        self.cumulative["fulfilled"] += fulfilled
        self.cumulative["urgent_demand"] += urgent_need
        self.cumulative["urgent_fulfilled"] += urgent_alloc
        self.cumulative["operational_cost"] += op_cost

        row = {
            "demand": s.current_demand,
            "urgent_demand": urgent_need,
            "fulfilled": fulfilled,
            "urgent_fulfilled": urgent_alloc,
            "service_level": service_level,
            "urgent_service": urgent_service,
            "backlog_end": s.backlog,
            "urgent_backlog_end": s.urgent_backlog,
            "inventory_end": s.inventory,
            "warehouse_capacity": warehouse_capacity,
            "transport_capacity_effective": transport_capacity,
            "decision_units": decision_units,
            "decision_budget_units": s.decision_budget_units,
            "deadline_met": deadline_met,
            "decision_delay_factor": decision_delay_factor,
            "operational_cost": op_cost,
            "operational_score": operational_score,
        }
        s.history.append(row)
        return row

    def episode_metrics(self) -> dict:
        c = self.cumulative
        service = c["fulfilled"] / max(c["demand"], 1.0)
        urgent = c["urgent_fulfilled"] / max(c["urgent_demand"], 1.0)
        final_backlog = self.state.backlog + 1.5 * self.state.urgent_backlog
        deadline_rate = 1.0 - c["deadline_misses"] / max(self.steps, 1)

        # V1.4 hotfix: replace the arbitrary absolute backlog threshold (32 units)
        # with a demand-normalised ratio.  A backlog of 30 units has a very
        # different meaning in a 70-unit-demand episode than in a 130-unit one.
        mean_step_demand = c["demand"] / max(self.steps, 1)
        backlog_ratio = final_backlog / max(mean_step_demand, 1.0)

        # Give genuinely more complex scenarios a modest allowance without
        # hard-coding individual scenario names. Complexity is measured by the
        # number of distinct causal dimensions in the scenario definition.
        #   3 dimensions -> 0.300
        #   4 dimensions -> 0.325
        #   5 dimensions -> 0.350
        #   6+ dimensions -> capped at 0.375
        causal_dimensions = len(set(self.scenario.causal_signature))
        complexity_excess = max(0, causal_dimensions - 3)
        backlog_ratio_limit = min(0.375, 0.30 + 0.025 * complexity_excess)
        backlog_success = int(backlog_ratio <= backlog_ratio_limit)

        # V1.4 relaxed-success hotfix:
        # Scenario success is a tolerant headline indicator rather than an
        # all-or-nothing gate. Four interpretable operational criteria are used.
        # A scenario is successful when at least 3 of 4 pass.
        #
        # 1) >=70% overall service
        # 2) >=70% urgent-order service
        # 3) backlog within the demand-normalised, complexity-adjusted limit
        # 4) >=70% of decision steps meet the deadline
        #
        # Critical constraint violations remain a hard veto and are NOT counted
        # as a fifth criterion. Continuous metrics should still be used for
        # detailed scientific comparison.
        service_success = int(service >= .70)
        urgent_success = int(urgent >= .70)
        deadline_success = int(deadline_rate >= .70)
        criteria_passed = service_success + urgent_success + backlog_success + deadline_success
        criteria_rate = criteria_passed / 4.0

        success = int(
            criteria_passed >= 3
            and c["constraint_violations"] == 0
        )

        # V1.4 evaluation refinement: continuous Scenario Achievement Score (SAS).
        # Each operational dimension is converted to target attainment in [0, 1].
        # The geometric mean requires balanced performance: strong dimensions cannot
        # completely hide a severe weakness in another dimension. This is an
        # evaluation metric only; the legacy scenario_success flag is retained for
        # backward compatibility with the frozen learning architecture.
        service_attainment = min(1.0, max(0.0, service / 0.70))
        urgent_attainment = min(1.0, max(0.0, urgent / 0.70))
        deadline_attainment = min(1.0, max(0.0, deadline_rate / 0.70))
        if backlog_ratio <= 0.0:
            backlog_attainment = 1.0
        else:
            backlog_attainment = min(1.0, max(0.0, backlog_ratio_limit / backlog_ratio))

        scenario_achievement_score = (
            service_attainment
            * urgent_attainment
            * backlog_attainment
            * deadline_attainment
        ) ** 0.25
        if c["constraint_violations"] > 0:
            scenario_achievement_score = 0.0

        return {
            "scenario_success": success,
            "scenario_achievement_score": scenario_achievement_score,
            "service_attainment": service_attainment,
            "urgent_attainment": urgent_attainment,
            "backlog_attainment": backlog_attainment,
            "deadline_attainment": deadline_attainment,
            "success_criteria_passed": criteria_passed,
            "success_criteria_rate": criteria_rate,
            "service_success": service_success,
            "urgent_success": urgent_success,
            "deadline_success": deadline_success,
            "episode_service_level": service,
            "episode_urgent_service": urgent,
            "final_weighted_backlog": final_backlog,
            "mean_step_demand": mean_step_demand,
            "final_backlog_ratio": backlog_ratio,
            "allowed_backlog_ratio": backlog_ratio_limit,
            "backlog_success": backlog_success,
            "scenario_causal_dimensions": causal_dimensions,
            "total_operational_cost": c["operational_cost"],
            "stockout_steps": c["stockout_steps"],
            "deadline_miss_rate": 1.0 - deadline_rate,
        }
