from __future__ import annotations
import os
from dataclasses import dataclass
from dotenv import load_dotenv
load_dotenv()
@dataclass
class Settings:
    ollama_url: str = os.getenv("OLLAMA_URL", "http://localhost:11434/api/generate")
    ollama_model: str = os.getenv("OLLAMA_MODEL", "qwen2.5:7b")
    openai_api_key: str | None = os.getenv("OPENAI_API_KEY")
    openai_l3_model: str = os.getenv("OPENAI_L3_MODEL", "gpt-4.1-mini-2025-04-14")
    pure_l3_model: str = os.getenv("PURE_L3_MODEL", "gpt-4.1-mini-2025-04-14")
