from __future__ import annotations
from dataclasses import dataclass
from .core import WorldState

CAUSAL_RULES = [
    "higher demand -> faster inventory depletion -> higher future stockout risk",
    "supplier delay -> later inbound inventory -> future stockout/backlog risk",
    "staff shortage -> lower warehouse throughput -> higher future backlog",
    "forklift failure -> reduced handling capacity -> late fulfilment risk",
    "transport disruption -> lower effective inbound/outbound capacity",
    "overtime -> higher short-term throughput but higher labour cost",
    "expedited transport -> higher dispatch capacity but higher transport cost",
    "urgent-priority allocation -> protects urgent orders but can defer normal backlog",
    "procurement today -> inventory only after supplier lead time",
    "stale or conflicting evidence -> confidence should fall until corroborated",
]

# Public capability metadata. This is not a fixed pipeline: several agents may
# cover the same causal requirement and some requirements emerge only at runtime.
FEATURE_AGENT_MAP = {
    "demand_pressure": {"A1_Demand", "A3_Inventory", "A6_Procurement"},
    "supplier_risk": {"A2_Supplier", "A3_Inventory", "A6_Procurement"},
    "inventory_risk": {"A1_Demand", "A3_Inventory", "A6_Procurement", "A7_Fulfilment"},
    "backlog_pressure": {"A3_Inventory", "A4_Warehouse", "A5_Staffing", "A7_Fulfilment", "A8_Transport"},
    "staff_shortage": {"A4_Warehouse", "A5_Staffing", "A7_Fulfilment"},
    "warehouse_constraint": {"A4_Warehouse", "A5_Staffing", "A7_Fulfilment"},
    "urgent_pressure": {"A3_Inventory", "A7_Fulfilment", "A8_Transport"},
    "transport_constraint": {"A8_Transport", "A6_Procurement", "A7_Fulfilment"},
    "deadline_pressure": {"A7_Fulfilment", "A8_Transport", "A4_Warehouse"},
    "evidence_conflict": {"A2_Supplier", "A6_Procurement", "A7_Fulfilment"},
    "regime_shift": {"A1_Demand", "A3_Inventory", "A6_Procurement"},
    "stable": {"A1_Demand", "A3_Inventory", "A6_Procurement"},
}

# Causal closure: if one feature is present, these downstream requirements may
# become important over the next few steps.
CAUSAL_FEATURE_EDGES = {
    "demand_pressure": {"inventory_risk", "urgent_pressure"},
    "supplier_risk": {"inventory_risk"},
    "inventory_risk": {"urgent_pressure"},
    "backlog_pressure": {"warehouse_constraint", "urgent_pressure"},
    "staff_shortage": {"warehouse_constraint"},
    "warehouse_constraint": {"urgent_pressure"},
    "transport_constraint": {"urgent_pressure"},
    "deadline_pressure": {"urgent_pressure"},
}

@dataclass
class WorldModel:
    state: WorldState

    def features(self) -> list[str]:
        s = self.state
        feats: list[str] = []
        reliable_inbound = sum(x.qty for x in s.incoming if not x.delayed)
        total_supply = s.inventory + reliable_inbound
        total_need = s.demand_forecast + .65 * s.backlog + .8 * s.urgent_backlog

        if s.demand_forecast + s.backlog > max(total_supply * .90, 1):
            feats.append("demand_pressure")
        if max(s.supplier_a_risk, s.supplier_b_risk) >= .28:
            feats.append("supplier_risk")
        if total_supply < total_need:
            feats.append("inventory_risk")
        if s.staff_available < s.base_staff:
            feats.append("staff_shortage")

        nominal = s.base_staff * s.throughput_per_worker
        actual = s.staff_available * s.throughput_per_worker * (1.0 if s.forklift_available else .62)
        workload = s.current_demand + s.backlog
        if s.backlog > 32:
            feats.append("backlog_pressure")
        if actual < .86 * nominal or actual < .92 * workload:
            feats.append("warehouse_constraint")
        if s.urgent_backlog + s.current_urgent_demand > .18 * max(workload, 1):
            feats.append("urgent_pressure")
        if s.transport_capacity < .88 * nominal or s.transport_capacity < .90 * workload or max(s.route_a_risk, s.route_b_risk) > .26:
            feats.append("transport_constraint")
        if s.decision_budget_units <= 6.6:
            feats.append("deadline_pressure")

        # Semantic conflict/retraction is a meaningful World Model state.
        event_types = {e.event_type for e in s.semantic_events}
        if "warning_retracted" in event_types or any(e.confidence < .65 for e in s.semantic_events):
            feats.append("evidence_conflict")

        # Regime change is inferred from recent demand error, not from hidden labels.
        if len(s.history) >= 2:
            recent = s.history[-2:]
            avg_d = sum(x.get("demand", 0) for x in recent) / 2
            if abs(avg_d - s.demand_forecast) / max(s.demand_forecast, 1) > .16:
                feats.append("regime_shift")

        return feats or ["stable"]

    def causal_closure(self) -> set[str]:
        closure = set(self.features())
        frontier = list(closure)
        while frontier:
            f = frontier.pop()
            for nxt in CAUSAL_FEATURE_EDGES.get(f, set()):
                if nxt not in closure:
                    closure.add(nxt)
                    frontier.append(nxt)
        return closure

    def relevant_agents(self) -> set[str]:
        # Evaluation target is the union of causally required capabilities.
        out: set[str] = set()
        for agents in self.causal_requirements().values():
            out |= agents
        return out or {"A1_Demand", "A3_Inventory", "A6_Procurement"}

    def causal_requirements(self) -> dict[str, set[str]]:
        """
        Capability-level requirements used by the minimum-sufficient selector.

        A feature is not considered covered merely because *some* related agent is
        present.  For example, supplier risk requires both observation (A2) and a
        response capability (A6). This is the key V1.4 change from "fewer agents"
        to "sufficient causal capability coverage".
        """
        req: dict[str, set[str]] = {}
        closure = self.causal_closure()
        if "demand_pressure" in closure or "regime_shift" in closure:
            req["demand_observation"] = {"A1_Demand"}
            req["demand_inventory_effect"] = {"A3_Inventory"}
            req["demand_response"] = {"A6_Procurement"}
        if "supplier_risk" in closure:
            req["supplier_assessment"] = {"A2_Supplier"}
            req["supplier_response"] = {"A6_Procurement"}
        if "inventory_risk" in closure:
            req["inventory_assessment"] = {"A3_Inventory"}
            req["inventory_response"] = {"A6_Procurement"}
        if "backlog_pressure" in closure:
            req["backlog_capacity_assessment"] = {"A4_Warehouse"}
            req["backlog_staff_response"] = {"A5_Staffing"}
            req["backlog_fulfilment"] = {"A7_Fulfilment"}
        if "staff_shortage" in closure:
            req["warehouse_capacity_assessment"] = {"A4_Warehouse"}
            req["staff_scheduling"] = {"A5_Staffing"}
        if "warehouse_constraint" in closure:
            req.setdefault("warehouse_capacity_assessment", {"A4_Warehouse"})
            req.setdefault("staff_scheduling", {"A5_Staffing"})
            req["warehouse_fulfilment_response"] = {"A7_Fulfilment"}
        if "transport_constraint" in closure:
            req["transport_assessment"] = {"A8_Transport"}
            req["transport_procurement_response"] = {"A6_Procurement"}
        if "urgent_pressure" in closure:
            req["fulfilment_priority"] = {"A7_Fulfilment"}
            req["urgent_transport"] = {"A8_Transport"}
        if "deadline_pressure" in closure:
            req["deadline_fulfilment"] = {"A7_Fulfilment"}
            req["deadline_transport"] = {"A8_Transport"}
        if "evidence_conflict" in closure:
            req["conflict_source_check"] = {"A2_Supplier"}
            req["conflict_decision_check"] = {"A6_Procurement"}
        if not req:
            req = {
                "demand_observation": {"A1_Demand"},
                "inventory_assessment": {"A3_Inventory"},
                "procurement_response": {"A6_Procurement"},
            }
        return req

    def context_signature(self) -> tuple[str, ...]:
        s = self.state
        tokens = set(self.features())
        tokens.add(f"phase:{s.phase}")
        tokens.add("backlog:high" if s.backlog > 45 else "backlog:low")
        tokens.add("inventory:low" if s.inventory < .9 * max(s.current_demand, 1) else "inventory:ok")
        tokens.add("supplier:A_risky" if s.supplier_a_risk > .28 else "supplier:A_ok")
        tokens.add("supplier:B_risky" if s.supplier_b_risk > .28 else "supplier:B_ok")
        tokens.add("route:B_risky" if s.route_b_risk > .26 else "route:B_ok")
        tokens.add("urgent:high" if s.current_urgent_demand + s.urgent_backlog > 20 else "urgent:normal")
        return tuple(sorted(tokens))

    def predicted_no_action(self) -> dict[str, float]:
        s = self.state
        cap = s.staff_available * s.throughput_per_worker * (1.0 if s.forklift_available else .62)
        next_backlog = max(0.0, s.current_demand + s.backlog - min(s.inventory, cap, s.transport_capacity))
        next_inventory = max(0.0, s.inventory - min(s.inventory, cap, s.current_demand + s.backlog))
        horizon2_need = max(0.0, s.demand_forecast + next_backlog - next_inventory)
        return {
            "next_inventory": round(next_inventory, 2),
            "next_backlog": round(next_backlog, 2),
            "horizon2_shortfall_proxy": round(horizon2_need, 2),
            "supplier_delay_risk_min": round(min(s.supplier_a_risk, s.supplier_b_risk), 3),
            "transport_route_risk_min": round(min(s.route_a_risk, s.route_b_risk), 3),
        }

    def view_for(self, agent: str) -> dict:
        s = self.state
        base = {
            "time": {"episode": s.episode, "step": s.step, "phase": s.phase},
            "scenario": s.scenario,
            "features": self.features(),
            "causal_closure": sorted(self.causal_closure()),
            "causal_rules": CAUSAL_RULES,
            "predicted_no_action": self.predicted_no_action(),
            "semantic_events": [
                {
                    "type": e.event_type,
                    "target": e.target,
                    "text": e.text,
                    "severity": e.severity,
                    "confidence": e.confidence,
                    "source": e.source,
                    "age": e.age,
                }
                for e in s.semantic_events
            ],
        }
        if agent == "A1_Demand":
            st = {"current_demand": s.current_demand, "demand_forecast": s.demand_forecast, "backlog": s.backlog, "urgent_backlog": s.urgent_backlog}
        elif agent == "A2_Supplier":
            st = {"supplier_a_risk": s.supplier_a_risk, "supplier_b_risk": s.supplier_b_risk, "supplier_a_lead": s.supplier_a_lead, "supplier_b_lead": s.supplier_b_lead, "incoming": [x.__dict__ for x in s.incoming]}
        elif agent == "A3_Inventory":
            st = {"inventory": s.inventory, "incoming": [x.__dict__ for x in s.incoming], "demand_forecast": s.demand_forecast, "backlog": s.backlog}
        elif agent == "A4_Warehouse":
            st = {"staff_available": s.staff_available, "base_staff": s.base_staff, "throughput_per_worker": s.throughput_per_worker, "forklift_available": s.forklift_available, "backlog": s.backlog}
        elif agent == "A5_Staffing":
            st = {"staff_available": s.staff_available, "base_staff": s.base_staff, "backlog": s.backlog, "current_demand": s.current_demand, "forklift_available": s.forklift_available}
        elif agent == "A6_Procurement":
            st = {"inventory": s.inventory, "incoming": [x.__dict__ for x in s.incoming], "demand_forecast": s.demand_forecast, "supplier_a_risk": s.supplier_a_risk, "supplier_b_risk": s.supplier_b_risk, "route_a_risk": s.route_a_risk, "route_b_risk": s.route_b_risk}
        elif agent == "A7_Fulfilment":
            st = {"inventory": s.inventory, "backlog": s.backlog, "urgent_backlog": s.urgent_backlog, "current_urgent_demand": s.current_urgent_demand, "transport_capacity": s.transport_capacity, "decision_budget_units": s.decision_budget_units}
        elif agent == "A8_Transport":
            st = {"transport_capacity": s.transport_capacity, "route_a_risk": s.route_a_risk, "route_b_risk": s.route_b_risk, "urgent_backlog": s.urgent_backlog, "current_urgent_demand": s.current_urgent_demand, "backlog": s.backlog}
        else:
            st = s.compact()
        base["state"] = st
        return base

    def full_view(self) -> dict:
        return {
            "state": self.state.compact(),
            "features": self.features(),
            "causal_closure": sorted(self.causal_closure()),
            "causal_rules": CAUSAL_RULES,
            "predicted_no_action": self.predicted_no_action(),
        }
