from __future__ import annotations
from pathlib import Path
from collections import Counter, defaultdict
import json
import math
import random
import pandas as pd

from .core import AGENTS, AGENT_EXECUTION_ORDER
from .scenarios import choose_scenario, SCENARIO_FAMILIES, MANIFEST_VERSION
from .environment import SupplyChainEnvironment
from .world_model import WorldModel
from .shell import CognitiveShell
from .agents import run_l1_agent, assemble_plan, LocalGeneralReasoner, FrontierCritic, PureL2Planner, PureL3Planner
from .learning import (
    MinimumSufficientTopologyQLambda,
    AdaptiveLevelQLambda,
    ContextualAgentTrust,
    CausalCapabilityGraph,
)
from .memory import ExperienceMemory, ExperienceCapsule
from .config import Settings

SYSTEMS = [
    "full_l1_shell",
    "expert_fixed_swarm",
    "fixed_hybrid",
    "vertical_evoswarm",
    "joint_evoswarm_cold",
    "joint_evoswarm",
    "pure_l2",
    "pure_l3",
]

RESOURCE_COST = {
    "agent_execution": .30,
    "shell_call": .55,
    "l2_call": 1.50,
    "l3_call": 3.00,
    "message": .06,
}

DECISION_UNITS = {
    "agent_execution": 1.0,
    "shell_call": .45,
    "l2_call": 2.0,
    "l3_call": 4.0,
    "message": .12,
}


def fixed_level(features):
    # Intentionally strong hand-designed baseline. It already knows several
    # domain-risk categories and always has the full specialist team available.
    hard = {"supplier_risk", "staff_shortage", "warehouse_constraint", "transport_constraint", "deadline_pressure"}
    n_hard = len(set(features) & hard)
    if n_hard >= 2 or "evidence_conflict" in features:
        return 3
    if n_hard >= 1 or "inventory_risk" in features or "regime_shift" in features:
        return 2
    return 1


def expert_fixed_agents(features):
    """Human-written feature -> specialist mapping baseline.

    This represents conventional expert orchestration: domain knowledge decides
    which L1 specialists participate. It does not learn and never invokes L2/L3.
    Rules use observable World-Model features only, not simulator ground-truth
    relevant-agent labels.
    """
    rules = {
        "stable": {"A1_Demand", "A3_Inventory", "A6_Procurement"},
        "demand_pressure": {"A1_Demand", "A3_Inventory", "A6_Procurement", "A7_Fulfilment"},
        "supplier_risk": {"A2_Supplier", "A3_Inventory", "A6_Procurement"},
        "inventory_risk": {"A1_Demand", "A3_Inventory", "A6_Procurement", "A7_Fulfilment"},
        "staff_shortage": {"A4_Warehouse", "A5_Staffing", "A7_Fulfilment"},
        "warehouse_constraint": {"A4_Warehouse", "A5_Staffing", "A7_Fulfilment"},
        "urgent_pressure": {"A3_Inventory", "A7_Fulfilment", "A8_Transport"},
        "transport_constraint": {"A7_Fulfilment", "A8_Transport"},
        "deadline_pressure": {"A4_Warehouse", "A5_Staffing", "A7_Fulfilment", "A8_Transport"},
        "evidence_conflict": {"A2_Supplier", "A6_Procurement", "A8_Transport"},
        "regime_shift": {"A1_Demand", "A2_Supplier", "A3_Inventory", "A6_Procurement"},
    }
    selected = set()
    for f in features:
        selected |= rules.get(f, set())
    if not selected:
        selected = set(rules["stable"])
    if set(features) & {"demand_pressure", "supplier_risk", "inventory_risk", "regime_shift"}:
        selected.add("A6_Procurement")
    return selected


def _run_agents_fixed(initial_agents, wm, shell):
    """Execute exactly the human-selected team; no runtime topology expansion."""
    bus = {}
    messages_by_agent = {}
    request_count = 0
    for agent in AGENT_EXECUTION_ORDER:
        if agent in initial_agents:
            m = run_l1_agent(agent, wm, shell, bus, None)
            bus[agent] = m
            messages_by_agent[agent] = m
            request_count += len(m.requests)
    messages = [messages_by_agent[a] for a in AGENT_EXECUTION_ORDER if a in messages_by_agent]
    return messages, set(messages_by_agent), len(messages), request_count


def _empty_guidance():
    return {"retrieved": [], "agent_bias": {}, "level_bias": {1: 0., 2: 0., 3: 0.}, "max_similarity": 0., "mean_similarity": 0.}


def _run_agents_dynamic(initial_agents, wm, shell, trust_scores=None, max_agents=8, allowed_edges=None):
    """Run the swarm with runtime expansion of both agents and evidence links.

    When ``allowed_edges`` is supplied (Joint EvoSwarm), each agent sees only the
    evidence links admitted by the learned communication topology. A REQUEST_AGENT
    can still reopen a pruned edge to an already-active source and refresh the
    requester, so topology contraction never blocks explicit runtime recovery.
    ``allowed_edges=None`` preserves the unrestricted behaviour of other systems.
    """
    bus = {}
    messages_by_agent = {}
    executed = set()
    execution_count = 0
    request_count = 0
    edge_expansion_count = 0
    requesters_to_refresh = set()
    learned_edges = None if allowed_edges is None else set(allowed_edges)

    def execute(agent):
        nonlocal execution_count, request_count
        if learned_edges is None:
            visible_bus = bus
        else:
            visible_bus = {src: msg for src, msg in bus.items() if (src, agent) in learned_edges}
        m = run_l1_agent(agent, wm, shell, visible_bus, trust_scores)
        bus[agent] = m
        messages_by_agent[agent] = m
        executed.add(agent)
        execution_count += 1
        request_count += len(m.requests)
        return m

    for agent in AGENT_EXECUTION_ORDER:
        if agent in initial_agents:
            execute(agent)

    # Up to two expansion rounds avoid unbounded dialogue while allowing both
    # new-agent recruitment and communication-edge reopening.
    for _ in range(2):
        missing = []
        requesters_to_refresh = set()
        for requester, m in list(messages_by_agent.items()):
            for req in m.requests:
                if req not in AGENTS:
                    continue
                if req not in executed and req not in missing and len(executed) + len(missing) < max_agents:
                    missing.append(req)
                    requesters_to_refresh.add(requester)
                elif (
                    learned_edges is not None
                    and req in executed
                    and (req, requester) in MinimumSufficientTopologyQLambda.KNOWN_FLOWS
                    and (req, requester) not in learned_edges
                ):
                    # Only reopen a true evidence-flow dependency. Some REQUEST_AGENT
                    # messages recruit a complementary/downstream capability rather
                    # than asking to read that agent's evidence; treating those as
                    # reverse communication edges would create meaningless cycles.
                    learned_edges.add((req, requester))
                    edge_expansion_count += 1
                    requesters_to_refresh.add(requester)

        if not missing and not requesters_to_refresh:
            break

        for agent in AGENT_EXECUTION_ORDER:
            if agent in missing:
                execute(agent)

        # Re-run decision-integrating requesters so newly requested evidence can
        # affect the current action rather than waiting until the next step.
        for requester in list(requesters_to_refresh):
            if requester in {"A3_Inventory", "A5_Staffing", "A6_Procurement", "A7_Fulfilment"}:
                execute(requester)

    messages = [messages_by_agent[a] for a in AGENT_EXECUTION_ORDER if a in messages_by_agent]
    return messages, executed, execution_count, request_count, edge_expansion_count, (learned_edges or set())


def _message_credits(messages):
    used = set()
    for m in messages:
        used |= set(m.evidence.get("used_agents", []))
    credits = {}
    for m in messages:
        c = .18
        if m.agent in used:
            c += .45
        q = m.proposal
        nontrivial = (
            q.get("order_qty", 0) > 0
            or q.get("overtime_workers", 0) > 0
            or bool(q.get("expedite_transport", False))
            or bool(q.get("rent_forklift", False))
            or ("urgent_priority" in q and (q["urgent_priority"] > .76 or q["urgent_priority"] < .64))
        )
        if nontrivial:
            c += .42
        if m.requests:
            c += .10
        credits[m.agent] = min(1.0, c)
    return credits



def _communication_edges(messages):
    """Directed realised evidence-flow edges (source_agent, target_agent)."""
    edges = set()
    for m in messages:
        for src in m.evidence.get("used_agents", []):
            if src in AGENTS and src != m.agent:
                edges.add((src, m.agent))
    return edges


def _agent_accuracy_signals(messages, wm, outcome):
    """Contextual reliability signals grounded in observable evidence accuracy."""
    s = wm.state
    signals = {}
    by = {m.agent: m for m in messages}

    if "A1_Demand" in by:
        pred = float(by["A1_Demand"].evidence.get("forecast", s.current_demand))
        err = abs(pred - s.current_demand) / max(s.current_demand, 1.0)
        signals["A1_Demand"] = max(-1.0, min(1.0, 1.0 - 4.0 * err))

    if "A2_Supplier" in by:
        e = by["A2_Supplier"].evidence
        err = (abs(float(e.get("risk_A", s.supplier_a_risk)) - s.supplier_a_risk) + abs(float(e.get("risk_B", s.supplier_b_risk)) - s.supplier_b_risk)) / 2
        signals["A2_Supplier"] = max(-1.0, min(1.0, 1.0 - 5.0 * err))

    if "A3_Inventory" in by:
        p = float(by["A3_Inventory"].evidence.get("stockout_risk", .5))
        target = 1.0 if (outcome["inventory_end"] < .18 * max(outcome["demand"], 1) or outcome["backlog_end"] > 55) else 0.0
        signals["A3_Inventory"] = max(-1.0, min(1.0, 1.0 - 2.0 * abs(p - target)))

    if "A4_Warehouse" in by:
        pred = float(by["A4_Warehouse"].evidence.get("capacity", 0))
        base = s.staff_available * s.throughput_per_worker * (1.0 if s.forklift_available else .62)
        err = abs(pred - base) / max(base, 1.0)
        signals["A4_Warehouse"] = max(-1.0, min(1.0, 1.0 - 4.0 * err))

    if "A8_Transport" in by:
        e = by["A8_Transport"].evidence
        err = (abs(float(e.get("route_risk_A", s.route_a_risk)) - s.route_a_risk) + abs(float(e.get("route_risk_B", s.route_b_risk)) - s.route_b_risk)) / 2
        signals["A8_Transport"] = max(-1.0, min(1.0, 1.0 - 5.0 * err))

    if "A7_Fulfilment" in by:
        signals["A7_Fulfilment"] = max(-1.0, min(1.0, 2.0 * outcome["urgent_service"] - 1.0))

    return signals

def _decision_resource(agent_exec, shell_calls, l2_used, l3_used, messages_count):
    rc = (
        RESOURCE_COST["agent_execution"] * agent_exec
        + RESOURCE_COST["shell_call"] * shell_calls
        + RESOURCE_COST["l2_call"] * l2_used
        + RESOURCE_COST["l3_call"] * l3_used
        + RESOURCE_COST["message"] * messages_count
    )
    du = (
        DECISION_UNITS["agent_execution"] * agent_exec
        + DECISION_UNITS["shell_call"] * shell_calls
        + DECISION_UNITS["l2_call"] * l2_used
        + DECISION_UNITS["l3_call"] * l3_used
        + DECISION_UNITS["message"] * messages_count
    )
    return rc, du


def _terminal_signal(ep_metrics, mean_operational_score, steps):
    service = ep_metrics["episode_service_level"]
    urgent = ep_metrics["episode_urgent_service"]
    backlog_score = 1.0 - min(1.0, ep_metrics["final_weighted_backlog"] / 120.0)
    cost_score = 1.0 - min(1.0, ep_metrics["total_operational_cost"] / max(steps * 500.0, 1))
    deadline_score = 1.0 - ep_metrics["deadline_miss_rate"]
    quality = .30 * service + .22 * urgent + .22 * backlog_score + .10 * cost_score + .11 * (mean_operational_score / 100.0) + .05 * deadline_score
    return max(-1.0, min(1.0, 2.0 * quality - 1.0))


def _new_joint_learners(seed):
    return (
        MinimumSufficientTopologyQLambda(seed + 101),
        AdaptiveLevelQLambda(seed + 202),
        ContextualAgentTrust(),
        CausalCapabilityGraph(),
        ExperienceMemory(),
    )



def _apply_experience_action_hint(plan, wm, guidance):
    """Conservatively reuse successful action tendencies in analogous contexts."""
    hint = guidance.get("action_hint") or {}
    sim = float(guidance.get("max_similarity", 0.0))
    if not hint or sim < .46:
        return plan
    # Keep experience as a bounded prior, never as a replayed action.
    w = max(.06, min(.18, (sim - .42) * .38))
    demand_scale = max(wm.state.current_demand, wm.state.demand_forecast, 1.0)
    hinted_order = hint.get("mean_order_ratio", 0.0) * demand_scale
    plan.order_qty = round((1 - w) * plan.order_qty + w * hinted_order)
    plan.overtime_workers = round((1 - w) * plan.overtime_workers + w * hint.get("mean_overtime", plan.overtime_workers))
    plan.urgent_priority = (1 - w) * plan.urgent_priority + w * hint.get("mean_urgent_priority", plan.urgent_priority)
    if hint.get("expedite_rate", 0.0) >= .72 and ("transport_constraint" in wm.features() or "urgent_pressure" in wm.features()):
        plan.expedite_transport = True
    return plan.clamp()

def run_system(system, episodes, steps, seed, llm_mode, include_pure_l3_live):
    rng = random.Random(seed)
    settings = Settings()
    shell = CognitiveShell(llm_mode, settings)
    l2 = LocalGeneralReasoner(llm_mode, settings)
    l3 = FrontierCritic(llm_mode, settings)
    pure_l2 = PureL2Planner(llm_mode, settings)
    pure = PureL3Planner(llm_mode, settings)

    topo, level_router, trust, graph, memory = _new_joint_learners(seed)
    vertical_level_router = AdaptiveLevelQLambda(seed + 303)

    if system == "pure_l3" and llm_mode == "live" and not include_pure_l3_live:
        return pd.DataFrame(), pd.DataFrame(), topo, level_router, trust, graph, memory

    step_rows = []
    ep_rows = []

    for ep in range(1, episodes + 1):
        # Cold control has identical architecture but cannot carry self-evolution
        # state across episodes.
        if system == "joint_evoswarm_cold":
            topo, level_router, trust, graph, memory = _new_joint_learners(seed * 1000 + ep)

        scenario = choose_scenario(ep, episodes, rng)
        env = SupplyChainEnvironment(scenario, ep, steps, seed * 10000 + ep)

        active_counts = []
        execution_counts = []
        communication_edge_counts = []
        predicted_edge_counts = []
        runtime_edge_expansion_counts = []
        support_added_counts = []
        support_pruned_counts = []
        topology_agent_additions = []
        topology_agent_removals = []
        topology_edge_additions = []
        topology_edge_removals = []
        previous_active_agents = None
        previous_communication_edges = None
        precisions = []
        recalls = []
        causal_coverages = []
        shell_calls_total = 0
        l2_calls = 0
        l3_calls = 0
        input_tokens = 0
        output_tokens = 0
        latency = 0.0
        fallbacks = 0
        retrievals = 0
        reuse_trials = 0
        reuse_useful = 0
        similarities = []
        regrets = []
        trust_floors = []
        transitions = []
        communication_transitions = []
        level_transitions = []
        episode_signature = set(scenario.causal_signature)
        agent_credit_sum = defaultdict(float)
        agent_credit_n = defaultdict(int)
        levels_used = []

        for step in range(steps):
            state = env.observe(step)
            wm = WorldModel(state)
            features = wm.features()
            requirements = wm.causal_requirements()
            relevant = wm.relevant_agents()
            signature = wm.context_signature()
            episode_signature.update(x for x in signature if not x.startswith("phase:"))

            messages = []
            executed = set()
            execution_count = 0
            communication_edges = set()
            predicted_edges = set()
            runtime_edge_expansions = 0
            support_added = 0
            support_pruned = 0
            request_count = 0
            guidance = _empty_guidance()
            trust_scores = None
            target_coverage = 1.0
            level = 2 if system == "pure_l2" else (3 if system == "pure_l3" else 1)

            if system == "pure_l2":
                plan, meta = pure_l2.plan(wm)
                l2_calls += 1
                input_tokens += meta.get("input_tokens", 0)
                output_tokens += meta.get("output_tokens", 0)
                latency += meta.get("latency_ms", 0)
                fallbacks += int(meta.get("fallback", False))
                precision = recall = causal_coverage = None
                shell_calls_step = 0
                resource_cost, decision_units = _decision_resource(0, 0, 1, 0, 1)
                trust_floor = None
                experience_reuse = None
                adaptation_regret = None
            elif system == "pure_l3":
                plan, meta = pure.plan(wm)
                l3_calls += 1
                input_tokens += meta.get("input_tokens", 0)
                output_tokens += meta.get("output_tokens", 0)
                latency += meta.get("latency_ms", 0)
                fallbacks += int(meta.get("fallback", False))
                precision = recall = causal_coverage = None
                shell_calls_step = 0
                resource_cost, decision_units = _decision_resource(0, 0, 0, 1, 1)
                trust_floor = None
                experience_reuse = None
                adaptation_regret = None
            else:
                is_joint = system in {"joint_evoswarm", "joint_evoswarm_cold"}
                if is_joint:
                    guidance = (
                        memory.guidance(tuple(sorted(set(signature) | set(scenario.causal_signature))), scenario=scenario.name)
                        if scenario.phase != "experience" else _empty_guidance()
                    )
                    if guidance["retrieved"]:
                        retrievals += 1
                        similarities.append(guidance["max_similarity"])
                        useful = ExperienceMemory.reuse_is_useful(guidance["retrieved"], relevant)
                        if useful is not None:
                            reuse_trials += 1
                            reuse_useful += int(useful)
                    trust_scores = {a: trust.score(a, features) for a in AGENTS}
                    selected, target_coverage = topo.select(
                        features, requirements, trust, graph,
                        experience_bias=guidance["agent_bias"],
                        min_agents=3,
                        max_agents=8,
                    )
                    predicted_edges = topo.communication_policy(
                        selected, features, graph, experience_bias=guidance["agent_bias"]
                    )
                    support_added = topo.last_support_added
                    support_pruned = topo.last_support_pruned
                elif system == "expert_fixed_swarm":
                    selected = expert_fixed_agents(features)
                else:
                    selected = set(AGENTS)

                if system == "expert_fixed_swarm":
                    messages, executed, execution_count, request_count = _run_agents_fixed(
                        selected, wm, shell
                    )
                else:
                    messages, executed, execution_count, request_count, runtime_edge_expansions, final_allowed_edges = _run_agents_dynamic(
                        selected, wm, shell, trust_scores if is_joint else None, max_agents=8,
                        allowed_edges=predicted_edges if is_joint else None,
                    )
                    if is_joint:
                        predicted_edges = final_allowed_edges
                plan = assemble_plan(messages, trust_scores if is_joint else None)
                # Experience changes future decisions only when a causally similar
                # situation reappears; it is not used during the initial experience phase.
                # V1.4 experience primarily evolves topology/trust/escalation.
                # Action profiles are stored for analysis but are not replayed into
                # decisions, avoiding a hidden case-based policy advantage.

                if system in {"full_l1_shell", "expert_fixed_swarm"}:
                    level = 1
                elif system == "fixed_hybrid":
                    level = fixed_level(features)
                elif system == "vertical_evoswarm":
                    level = vertical_level_router.choose(features, trust_floor=1.0)
                else:
                    selected_trusts = [trust_scores[a] for a in executed] if executed else [.5]
                    trust_floor = min(selected_trusts)
                    trust_floors.append(trust_floor)
                    level = level_router.choose(features, guidance["level_bias"], trust_floor)

                levels_used.append(level)
                if level >= 2:
                    plan, meta = l2.refine(wm, messages, plan)
                    l2_calls += 1
                    input_tokens += meta.get("input_tokens", 0)
                    output_tokens += meta.get("output_tokens", 0)
                    latency += meta.get("latency_ms", 0)
                    fallbacks += int(meta.get("fallback", False))
                if level >= 3:
                    plan, meta = l3.refine(wm, messages, plan)
                    l3_calls += 1
                    input_tokens += meta.get("input_tokens", 0)
                    output_tokens += meta.get("output_tokens", 0)
                    latency += meta.get("latency_ms", 0)
                    fallbacks += int(meta.get("fallback", False))

                shell_calls_step = sum(int(m.shell_used) for m in messages)
                shell_calls_total += shell_calls_step
                input_tokens += sum(m.shell_input_tokens for m in messages)
                output_tokens += sum(m.shell_output_tokens for m in messages)
                latency += sum(m.shell_latency_ms for m in messages)
                fallbacks += sum(int(m.shell_fallback) for m in messages)

                communication_edges = _communication_edges(messages)
                communication_edge_counts.append(len(communication_edges))
                predicted_edge_counts.append(len(predicted_edges) if is_joint else len(communication_edges))
                runtime_edge_expansion_counts.append(runtime_edge_expansions if is_joint else 0)
                support_added_counts.append(support_added if is_joint else 0)
                support_pruned_counts.append(support_pruned if is_joint else 0)
                if is_joint and previous_active_agents is not None:
                    topology_agent_additions.append(len(executed - previous_active_agents))
                    topology_agent_removals.append(len(previous_active_agents - executed))
                    topology_edge_additions.append(len(communication_edges - previous_communication_edges))
                    topology_edge_removals.append(len(previous_communication_edges - communication_edges))
                elif is_joint:
                    topology_agent_additions.append(0)
                    topology_agent_removals.append(0)
                    topology_edge_additions.append(0)
                    topology_edge_removals.append(0)
                else:
                    topology_agent_additions.append(0)
                    topology_agent_removals.append(0)
                    topology_edge_additions.append(0)
                    topology_edge_removals.append(0)
                previous_active_agents = set(executed) if is_joint else previous_active_agents
                previous_communication_edges = set(communication_edges) if is_joint else previous_communication_edges
                active_counts.append(len(executed))
                execution_counts.append(execution_count)
                precision = len(executed & relevant) / max(len(executed), 1)
                recall = len(executed & relevant) / max(len(relevant), 1)
                causal_coverage = topo.coverage(executed, requirements) if (is_joint or system == "expert_fixed_swarm") else 1.0
                precisions.append(precision)
                recalls.append(recall)
                causal_coverages.append(causal_coverage)

                msg_count = len(messages) + request_count
                resource_cost, decision_units = _decision_resource(
                    execution_count, shell_calls_step, int(level >= 2), int(level >= 3), msg_count
                )

                if not is_joint:
                    trust_floor = None
                    experience_reuse = None
                    adaptation_regret = None
                else:
                    experience_reuse = ExperienceMemory.reuse_is_useful(guidance["retrieved"], relevant)
                    adaptation_regret = None  # filled after reward is known

            outcome = env.step(plan, decision_units)

            # Operational quality dominates; resource use is intentionally a small
            # secondary term. Missing causal coverage receives a stronger penalty.
            coverage_penalty = 0.0 if causal_coverage is None else .10 * (1.0 - causal_coverage)
            learning_reward = outcome["operational_score"] / 100.0 - .006 * resource_cost - coverage_penalty

            if system in {"joint_evoswarm", "joint_evoswarm_cold"}:
                credits = _message_credits(messages)
                outcome_signal = max(-1.0, min(1.0, (outcome["operational_score"] - 68.0) / 30.0))
                topo.update(features, executed, learning_reward, credits, communication_edges)
                level_router.update(features, level, learning_reward)
                graph.update(features, executed, outcome_signal, credits, communication_edges)
                accuracy_signals = _agent_accuracy_signals(messages, wm, outcome)
                for a in executed:
                    if a in accuracy_signals:
                        trust.update(features, a, accuracy_signals[a], credits.get(a, .25))
                    agent_credit_sum[a] += credits.get(a, .25)
                    agent_credit_n[a] += 1
                transitions.append((tuple(features), set(executed), credits, set(communication_edges)))
                communication_transitions.append((tuple(features), set(executed), credits, set(communication_edges)))
                level_transitions.append((tuple(features), level))

                if guidance["retrieved"]:
                    best_prior = max(cap.reward for _, cap in guidance["retrieved"])
                    adaptation_regret = max(0.0, best_prior - learning_reward)
                    regrets.append(adaptation_regret)
            elif system == "vertical_evoswarm":
                vertical_level_router.update(features, level, learning_reward)

            step_rows.append({
                "system": system,
                "episode": ep,
                "phase": scenario.phase,
                "scenario": scenario.name,
                "scenario_variant": scenario.variant,
                "step": step,
                "features": ";".join(features),
                "active_agents": ";".join(sorted(executed)),
                "active_agent_count": len(executed),
                "agent_execution_count": execution_count,
                "communication_edge_count": len(communication_edges),
                "communication_edges": ";".join(f"{a}->{b}" for a, b in sorted(communication_edges)),
                "predicted_communication_edge_count": len(predicted_edges) if system in {"joint_evoswarm", "joint_evoswarm_cold"} else len(communication_edges),
                "predicted_communication_edges": ";".join(f"{a}->{b}" for a, b in sorted(predicted_edges)) if system in {"joint_evoswarm", "joint_evoswarm_cold"} else "",
                "runtime_edge_expansions": runtime_edge_expansions if system in {"joint_evoswarm", "joint_evoswarm_cold"} else 0,
                "support_agents_added": support_added if system in {"joint_evoswarm", "joint_evoswarm_cold"} else 0,
                "support_agents_pruned": support_pruned if system in {"joint_evoswarm", "joint_evoswarm_cold"} else 0,
                "topology_agent_additions": topology_agent_additions[-1] if topology_agent_additions else 0,
                "topology_agent_removals": topology_agent_removals[-1] if topology_agent_removals else 0,
                "topology_edge_additions": topology_edge_additions[-1] if topology_edge_additions else 0,
                "topology_edge_removals": topology_edge_removals[-1] if topology_edge_removals else 0,
                "agent_precision": precision,
                "agent_recall": recall,
                "causal_coverage": causal_coverage,
                "target_causal_coverage": target_coverage if system in {"joint_evoswarm", "joint_evoswarm_cold"} else None,
                "runtime_requests": request_count,
                "level_used": level,
                "trust_floor": trust_floor,
                "experience_retrieved": int(bool(guidance["retrieved"])) if system in {"joint_evoswarm", "joint_evoswarm_cold"} else 0,
                "experience_similarity": guidance["max_similarity"] if system in {"joint_evoswarm", "joint_evoswarm_cold"} else 0.0,
                "experience_reuse_useful": (int(experience_reuse) if experience_reuse is not None else None),
                "adaptation_regret": adaptation_regret,
                "order_qty": plan.order_qty,
                "supplier": plan.supplier,
                "overtime_workers": plan.overtime_workers,
                "urgent_priority": plan.urgent_priority,
                "expedite_transport": plan.expedite_transport,
                "rent_forklift": plan.rent_forklift,
                "resource_cost": resource_cost,
                "learning_reward": learning_reward,
                **outcome,
            })

        ep_metrics = env.episode_metrics()
        ep_step = pd.DataFrame([r for r in step_rows if r["system"] == system and r["episode"] == ep])
        mean_op = float(ep_step["operational_score"].mean())
        terminal_signal = _terminal_signal(ep_metrics, mean_op, steps)

        if system in {"joint_evoswarm", "joint_evoswarm_cold"}:
            topo.retrospective_update(transitions, terminal_signal)
            level_router.retrospective_update(level_transitions, terminal_signal)
            # Terminal downstream credit also updates trust and causal graph.
            for features, selected, credits, comm_edges in communication_transitions:
                graph.update(features, selected, terminal_signal, credits, comm_edges)

            if system == "joint_evoswarm":
                useful_agents = tuple(sorted(
                    a for a in agent_credit_sum
                    if agent_credit_sum[a] / max(agent_credit_n[a], 1) >= .50
                ))
                dominant_level = Counter(levels_used).most_common(1)[0][0] if levels_used else 1
                mean_order_ratio = float((ep_step["order_qty"] / ep_step["demand"].clip(lower=1.0)).mean())
                memory.add(ExperienceCapsule(
                    episode=ep,
                    phase=scenario.phase,
                    scenario=scenario.name,
                    signature=tuple(sorted(episode_signature)),
                    agents=tuple(sorted(set().union(*(t[1] for t in transitions)))) if transitions else tuple(),
                    useful_agents=useful_agents,
                    level=dominant_level,
                    reward=float(ep_step["learning_reward"].mean()),
                    operational_score=mean_op,
                    resource_cost=float(ep_step["resource_cost"].mean()),
                    success=ep_metrics["scenario_success"],
                    final_backlog=ep_metrics["final_weighted_backlog"],
                    mean_order_ratio=mean_order_ratio,
                    mean_overtime=float(ep_step["overtime_workers"].mean()),
                    mean_urgent_priority=float(ep_step["urgent_priority"].mean()),
                    expedite_rate=float(ep_step["expedite_transport"].mean()),
                    supplier_b_rate=float((ep_step["supplier"] == "B").mean()),
                ))

        ep_rows.append({
            "system": system,
            "episode": ep,
            "phase": scenario.phase,
            "scenario": scenario.name,
            "scenario_variant": scenario.variant,
            **ep_metrics,
            "mean_operational_score": mean_op,
            "mean_step_service": float(ep_step["service_level"].mean()),
            "mean_step_urgent_service": float(ep_step["urgent_service"].mean()),
            "mean_active_agents": sum(active_counts) / max(len(active_counts), 1) if system not in {"pure_l2", "pure_l3"} else 0.0,
            "mean_agent_executions": sum(execution_counts) / max(len(execution_counts), 1) if execution_counts else 0.0,
            "mean_communication_edges": sum(communication_edge_counts) / max(len(communication_edge_counts), 1) if communication_edge_counts else 0.0,
            "mean_predicted_communication_edges": sum(predicted_edge_counts) / max(len(predicted_edge_counts), 1) if predicted_edge_counts else 0.0,
            "mean_runtime_edge_expansions": sum(runtime_edge_expansion_counts) / max(len(runtime_edge_expansion_counts), 1) if runtime_edge_expansion_counts else 0.0,
            "mean_support_agents_added": sum(support_added_counts) / max(len(support_added_counts), 1) if support_added_counts else 0.0,
            "mean_support_agents_pruned": sum(support_pruned_counts) / max(len(support_pruned_counts), 1) if support_pruned_counts else 0.0,
            "mean_topology_agent_additions": sum(topology_agent_additions) / max(len(topology_agent_additions), 1) if topology_agent_additions else 0.0,
            "mean_topology_agent_removals": sum(topology_agent_removals) / max(len(topology_agent_removals), 1) if topology_agent_removals else 0.0,
            "mean_topology_edge_additions": sum(topology_edge_additions) / max(len(topology_edge_additions), 1) if topology_edge_additions else 0.0,
            "mean_topology_edge_removals": sum(topology_edge_removals) / max(len(topology_edge_removals), 1) if topology_edge_removals else 0.0,
            "mean_agent_precision": sum(precisions) / max(len(precisions), 1) if precisions else None,
            "mean_agent_recall": sum(recalls) / max(len(recalls), 1) if recalls else None,
            "mean_causal_coverage": sum(causal_coverages) / max(len(causal_coverages), 1) if causal_coverages else None,
            "shell_calls": shell_calls_total,
            "l2_calls": l2_calls,
            "l3_calls": l3_calls,
            "input_tokens": input_tokens,
            "output_tokens": output_tokens,
            "llm_latency_ms": latency,
            "fallback_count": fallbacks,
            "mean_resource_cost": float(ep_step["resource_cost"].mean()),
            "mean_decision_units": float(ep_step["decision_units"].mean()),
            "mean_learning_reward": float(ep_step["learning_reward"].mean()),
            "experience_retrieval_rate": retrievals / max(steps, 1),
            "mean_experience_similarity": sum(similarities) / max(len(similarities), 1) if similarities else 0.0,
            "experience_reuse_accuracy": reuse_useful / max(reuse_trials, 1) if reuse_trials else None,
            "mean_adaptation_regret": sum(regrets) / max(len(regrets), 1) if regrets else None,
            "mean_trust_floor": sum(trust_floors) / max(len(trust_floors), 1) if trust_floors else None,
            "terminal_signal": terminal_signal,
        })

    return pd.DataFrame(step_rows), pd.DataFrame(ep_rows), topo, level_router, trust, graph, memory


def _summaries(episodes_df):
    summary = (
        episodes_df.groupby("system")
        .agg(
            episodes=("episode", "count"),
            scenario_achievement_score=("scenario_achievement_score", "mean"),
            legacy_scenario_success_rate=("scenario_success", "mean"),
            mean_success_criteria_passed=("success_criteria_passed", "mean"),
            mean_success_criteria_rate=("success_criteria_rate", "mean"),
            service_success_rate=("service_success", "mean"),
            urgent_success_rate=("urgent_success", "mean"),
            deadline_success_rate=("deadline_success", "mean"),
            service_level=("episode_service_level", "mean"),
            urgent_service=("episode_urgent_service", "mean"),
            mean_operational_score=("mean_operational_score", "mean"),
            final_backlog=("final_weighted_backlog", "mean"),
            backlog_ratio=("final_backlog_ratio", "mean"),
            allowed_backlog_ratio=("allowed_backlog_ratio", "mean"),
            backlog_success_rate=("backlog_success", "mean"),
            mean_scenario_causal_dimensions=("scenario_causal_dimensions", "mean"),
            operational_cost=("total_operational_cost", "mean"),
            deadline_miss_rate=("deadline_miss_rate", "mean"),
            active_agents=("mean_active_agents", "mean"),
            agent_executions=("mean_agent_executions", "mean"),
            communication_edges=("mean_communication_edges", "mean"),
            predicted_communication_edges=("mean_predicted_communication_edges", "mean"),
            runtime_edge_expansions=("mean_runtime_edge_expansions", "mean"),
            support_agents_added=("mean_support_agents_added", "mean"),
            support_agents_pruned=("mean_support_agents_pruned", "mean"),
            topology_agent_additions=("mean_topology_agent_additions", "mean"),
            topology_agent_removals=("mean_topology_agent_removals", "mean"),
            topology_edge_additions=("mean_topology_edge_additions", "mean"),
            topology_edge_removals=("mean_topology_edge_removals", "mean"),
            agent_precision=("mean_agent_precision", "mean"),
            agent_recall=("mean_agent_recall", "mean"),
            causal_coverage=("mean_causal_coverage", "mean"),
            shell_calls=("shell_calls", "mean"),
            l2_calls=("l2_calls", "mean"),
            l3_calls=("l3_calls", "mean"),
            input_tokens=("input_tokens", "sum"),
            output_tokens=("output_tokens", "sum"),
            llm_latency_ms=("llm_latency_ms", "sum"),
            fallback_count=("fallback_count", "sum"),
            resource_cost=("mean_resource_cost", "mean"),
            decision_units=("mean_decision_units", "mean"),
            experience_retrieval_rate=("experience_retrieval_rate", "mean"),
            experience_reuse_accuracy=("experience_reuse_accuracy", "mean"),
            adaptation_regret=("mean_adaptation_regret", "mean"),
        )
        .reset_index()
    )

    scenario_summary = (
        episodes_df.groupby(["system", "scenario"])
        .agg(
            n=("episode", "count"),
            scenario_achievement_score=("scenario_achievement_score", "mean"),
            legacy_success_rate=("scenario_success", "mean"),
            mean_criteria_passed=("success_criteria_passed", "mean"),
            service_success_rate=("service_success", "mean"),
            urgent_success_rate=("urgent_success", "mean"),
            deadline_success_rate=("deadline_success", "mean"),
            service=("episode_service_level", "mean"),
            urgent_service=("episode_urgent_service", "mean"),
            operational_score=("mean_operational_score", "mean"),
            backlog=("final_weighted_backlog", "mean"),
            backlog_ratio=("final_backlog_ratio", "mean"),
            allowed_backlog_ratio=("allowed_backlog_ratio", "mean"),
            backlog_success_rate=("backlog_success", "mean"),
            deadline_miss_rate=("deadline_miss_rate", "mean"),
            active_agents=("mean_active_agents", "mean"),
            communication_edges=("mean_communication_edges", "mean"),
            predicted_communication_edges=("mean_predicted_communication_edges", "mean"),
            runtime_edge_expansions=("mean_runtime_edge_expansions", "mean"),
            agent_recall=("mean_agent_recall", "mean"),
            causal_coverage=("mean_causal_coverage", "mean"),
            l3_calls=("l3_calls", "mean"),
        )
        .reset_index()
    )

    phase_summary = (
        episodes_df.groupby(["system", "phase"])
        .agg(
            n=("episode", "count"),
            scenario_achievement_score=("scenario_achievement_score", "mean"),
            legacy_success_rate=("scenario_success", "mean"),
            service=("episode_service_level", "mean"),
            operational_score=("mean_operational_score", "mean"),
            backlog=("final_weighted_backlog", "mean"),
            active_agents=("mean_active_agents", "mean"),
            communication_edges=("mean_communication_edges", "mean"),
            predicted_communication_edges=("mean_predicted_communication_edges", "mean"),
            runtime_edge_expansions=("mean_runtime_edge_expansions", "mean"),
            agent_recall=("mean_agent_recall", "mean"),
            causal_coverage=("mean_causal_coverage", "mean"),
            resource_cost=("mean_resource_cost", "mean"),
            l3_calls=("l3_calls", "mean"),
            retrieval_rate=("experience_retrieval_rate", "mean"),
            reuse_accuracy=("experience_reuse_accuracy", "mean"),
            adaptation_regret=("mean_adaptation_regret", "mean"),
        )
        .reset_index()
    )

    return summary, scenario_summary, phase_summary


def _self_evolution_summary(phase_summary):
    rows = []
    for phase in ["experience", "recurrence", "generalisation"]:
        p = phase_summary[phase_summary.phase == phase].set_index("system")
        if "joint_evoswarm" not in p.index or "joint_evoswarm_cold" not in p.index:
            continue
        e = p.loc["joint_evoswarm"]
        c = p.loc["joint_evoswarm_cold"]
        rows.append({
            "phase": phase,
            "experience_gain_operational_score": e.operational_score - c.operational_score,
            "experience_gain_scenario_achievement_score": e.scenario_achievement_score - c.scenario_achievement_score,
            "legacy_experience_gain_success_rate": e.legacy_success_rate - c.legacy_success_rate,
            "experience_gain_service": e.service - c.service,
            "resource_learning_gain": c.resource_cost - e.resource_cost,
            "active_agent_change": e.active_agents - c.active_agents,
            "agent_recall_gain": e.agent_recall - c.agent_recall,
            "causal_coverage_gain": e.causal_coverage - c.causal_coverage,
            "l3_calls_saved": c.l3_calls - e.l3_calls,
            "experience_retrieval_rate": e.retrieval_rate,
            "swarm_reuse_accuracy": e.reuse_accuracy,
            "adaptation_regret": e.adaptation_regret,
        })
    return pd.DataFrame(rows)


def run_all(episodes, steps, seed, llm_mode, output_dir, include_pure_l3_live=False, systems=None):
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    systems = systems or SYSTEMS

    step_frames = []
    ep_frames = []
    joint_artifacts = None

    for sys in systems:
        s, e, topo, level, trust, graph, memory = run_system(
            sys, episodes, steps, seed, llm_mode, include_pure_l3_live
        )
        if not s.empty:
            step_frames.append(s)
            ep_frames.append(e)
        if sys == "joint_evoswarm":
            joint_artifacts = (topo, level, trust, graph, memory)

    # Preserve schema columns even when a selected subset (for example pure_l2 only)
    # contains metrics that are intentionally all-NaN, such as agent precision/recall
    # and self-evolution fields. Dropping all-NaN columns here made the summary
    # aggregation fail for single-system runs.
    steps_df = pd.concat(step_frames, ignore_index=True, sort=False)
    episodes_df = pd.concat(ep_frames, ignore_index=True, sort=False)
    summary, scenario_summary, phase_summary = _summaries(episodes_df)
    self_evolution = _self_evolution_summary(phase_summary)

    steps_df.to_csv(out / "step_results.csv", index=False)
    episodes_df.to_csv(out / "episode_results.csv", index=False)
    summary.to_csv(out / "summary.csv", index=False)
    scenario_summary.to_csv(out / "scenario_summary.csv", index=False)
    phase_summary.to_csv(out / "phase_summary.csv", index=False)
    self_evolution.to_csv(out / "self_evolution_summary.csv", index=False)

    manifest_cols = ["episode", "phase", "scenario", "scenario_variant"]
    manifest_df = episodes_df[manifest_cols].drop_duplicates().sort_values("episode")
    manifest_df.to_csv(out / "scenario_manifest.csv", index=False)

    if joint_artifacts:
        topo, level, trust, graph, memory = joint_artifacts
        pd.DataFrame(topo.rows()).to_csv(out / "joint_agent_qtable.csv", index=False)
        pd.DataFrame(topo.pair_rows()).to_csv(out / "joint_pair_qtable.csv", index=False)
        pd.DataFrame(level.rows()).to_csv(out / "joint_level_qtable.csv", index=False)
        pd.DataFrame(trust.rows()).to_csv(out / "contextual_agent_trust.csv", index=False)
        pd.DataFrame(graph.rows()).to_csv(out / "causal_capability_graph.csv", index=False)
        pd.DataFrame(graph.pair_rows()).to_csv(out / "causal_agent_pair_graph.csv", index=False)
        pd.DataFrame(memory.rows()).to_csv(out / "experience_memory.csv", index=False)

    metadata = {
        "version": "1.4",
        "episodes": episodes,
        "steps_per_episode": steps,
        "seed": seed,
        "llm_mode": llm_mode,
        "systems": systems,
        "scenario_families": SCENARIO_FAMILIES,
        "scenario_manifest_version": MANIFEST_VERSION,
        "scenario_manifest_file": "scenario_manifest.csv",
        "pure_l2_model": Settings().ollama_model,
        "pure_l3_model": Settings().pure_l3_model,
        "evoswarm_l3_model": Settings().openai_l3_model,
        "self_evolution_definition": "causal downstream credit modifies future topology, contextual trust, capability graph, experience guidance, and intelligence escalation",
        "joint_objective": "minimum sufficient swarm, not minimum swarm",
    }
    (out / "run_metadata.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")
    return steps_df, episodes_df, summary, scenario_summary, phase_summary, self_evolution
