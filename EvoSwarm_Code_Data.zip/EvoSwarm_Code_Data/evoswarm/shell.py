from __future__ import annotations
import json
import time
import urllib.request
from collections import OrderedDict
from dataclasses import dataclass, field
from .config import Settings

@dataclass
class ShellResult:
    adjustments: dict = field(default_factory=dict)
    used: bool = False
    input_tokens: int = 0
    output_tokens: int = 0
    latency_ms: float = 0.0
    fallback: bool = False
    cache_hit: bool = False

class CognitiveShell:
    """Selective local semantic interface; it never makes the final decision."""

    def __init__(self, mode="proxy", settings=None, cache_size=512):
        self.mode = mode
        self.settings = settings or Settings()
        # Exact semantic-state LRU cache. The key includes evidence age, so a
        # temporally changed/stale event is interpreted again. Failed responses
        # are never cached. This mainly removes duplicate Ollama calls when an
        # agent is re-executed after REQUEST_AGENT expansion in the same step.
        self.cache_size = max(0, int(cache_size))
        self._cache = OrderedDict()

    @staticmethod
    def _cache_key(agent, events):
        return agent + "|" + json.dumps(events, sort_keys=True, separators=(",", ":"), ensure_ascii=False)

    def _cache_get(self, key):
        if self.cache_size <= 0 or key not in self._cache:
            return None
        cached = self._cache.pop(key)
        self._cache[key] = cached
        # Cache reuse is not another Ollama call, so tokens/latency and `used`
        # are zero/False. The semantic adjustments are still available to the agent.
        return ShellResult(
            adjustments=dict(cached.adjustments),
            used=False,
            input_tokens=0,
            output_tokens=0,
            latency_ms=0.0,
            fallback=False,
            cache_hit=True,
        )

    def _cache_put(self, key, result):
        if self.cache_size <= 0 or result.fallback:
            return
        if key in self._cache:
            self._cache.pop(key)
        self._cache[key] = ShellResult(
            adjustments=dict(result.adjustments),
            used=True,
            input_tokens=result.input_tokens,
            output_tokens=result.output_tokens,
            latency_ms=result.latency_ms,
            fallback=False,
            cache_hit=False,
        )
        while len(self._cache) > self.cache_size:
            self._cache.popitem(last=False)

    def interpret(self, agent, view):
        events = view.get("semantic_events", [])
        rel = [e for e in events if self._relevant(agent, e.get("target", ""))]
        if not rel:
            return ShellResult()
        if self.mode != "live":
            return self._proxy(rel)

        cache_key = self._cache_key(agent, rel)
        cached = self._cache_get(cache_key)
        if cached is not None:
            return cached

        prompt = f'''You are a low-cost semantic interface for specialist agent {agent}.
Do NOT make the final supply-chain decision. Convert only relevant semantic evidence
into bounded numerical adjustments. Consider source confidence, negative/retraction
events, and evidence age. Return JSON only.

Events:
{json.dumps(rel, indent=2)}

Allowed keys:
demand_multiplier,
supplier_a_risk_delta,
supplier_b_risk_delta,
staff_delta,
warehouse_capacity_multiplier,
transport_capacity_multiplier,
route_a_risk_delta,
route_b_risk_delta,
urgent_priority_delta,
confidence.'''
        payload = {
            "model": self.settings.ollama_model,
            "prompt": prompt,
            "stream": False,
            "format": "json",
            "options": {"temperature": 0.0},
        }
        req = urllib.request.Request(
            self.settings.ollama_url,
            data=json.dumps(payload).encode(),
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        try:
            st = time.perf_counter()
            with urllib.request.urlopen(req, timeout=120) as r:
                res = json.loads(r.read().decode())
            d = json.loads(res.get("response", "{}"))
            lat = (time.perf_counter() - st) * 1000
            result = ShellResult(
                self._clamp(d), True,
                int(res.get("prompt_eval_count", 0) or 0),
                int(res.get("eval_count", 0) or 0),
                lat, False, False,
            )
            self._cache_put(cache_key, result)
            return result
        except Exception:
            x = self._proxy(rel)
            x.fallback = True
            return x

    @staticmethod
    def _relevant(agent, target):
        mapping = {
            "A1_Demand": {"demand"},
            "A2_Supplier": {"supplier_A", "supplier_B"},
            "A4_Warehouse": {"warehouse"},
            "A5_Staffing": {"staffing"},
            "A7_Fulfilment": {"fulfilment"},
            "A8_Transport": {"transport", "transport_A", "transport_B"},
        }
        return target in mapping.get(agent, set())

    def _proxy(self, events):
        out = {}
        for e in events:
            sev = float(e.get("severity", 0))
            conf = float(e.get("confidence", .7))
            age = float(e.get("age", 0))
            freshness = max(.45, 1.0 - .18 * age)
            effective = sev * conf * freshness
            t = e.get("target")
            if t == "demand":
                out["demand_multiplier"] = out.get("demand_multiplier", 1.0) * (1 + effective)
            elif t == "supplier_A":
                out["supplier_a_risk_delta"] = out.get("supplier_a_risk_delta", 0.0) + effective
            elif t == "supplier_B":
                out["supplier_b_risk_delta"] = out.get("supplier_b_risk_delta", 0.0) + effective
            elif t == "staffing":
                out["staff_delta"] = out.get("staff_delta", 0.0) - effective * 8
            elif t == "warehouse":
                out["warehouse_capacity_multiplier"] = out.get("warehouse_capacity_multiplier", 1.0) * max(.55, 1 - max(0.0, effective))
            elif t in {"transport", "transport_A", "transport_B"}:
                out["transport_capacity_multiplier"] = out.get("transport_capacity_multiplier", 1.0) * max(.60, 1 - max(0.0, effective) * .55)
                if t == "transport_A":
                    out["route_a_risk_delta"] = out.get("route_a_risk_delta", 0.0) + effective
                if t == "transport_B":
                    out["route_b_risk_delta"] = out.get("route_b_risk_delta", 0.0) + effective
            elif t == "fulfilment":
                out["urgent_priority_delta"] = out.get("urgent_priority_delta", 0.0) + max(0.0, effective) * .30
        out["confidence"] = sum(float(e.get("confidence", .7)) for e in events) / max(len(events), 1)
        return ShellResult(self._clamp(out), True)

    @staticmethod
    def _clamp(d):
        defs = {
            "demand_multiplier": (.65, 1.45, 1.0),
            "supplier_a_risk_delta": (-.45, .45, 0.0),
            "supplier_b_risk_delta": (-.45, .45, 0.0),
            "staff_delta": (-5, 5, 0.0),
            "warehouse_capacity_multiplier": (.50, 1.20, 1.0),
            "transport_capacity_multiplier": (.50, 1.20, 1.0),
            "route_a_risk_delta": (-.40, .40, 0.0),
            "route_b_risk_delta": (-.40, .40, 0.0),
            "urgent_priority_delta": (-.25, .25, 0.0),
            "confidence": (0, 1, .7),
        }
        out = {}
        for k, (lo, hi, default) in defs.items():
            try:
                out[k] = max(lo, min(hi, float(d.get(k, default))))
            except Exception:
                out[k] = default
        return out
