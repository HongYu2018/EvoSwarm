from __future__ import annotations
from dataclasses import dataclass, field, asdict
from typing import Any

AGENTS = [
    "A1_Demand",
    "A2_Supplier",
    "A3_Inventory",
    "A4_Warehouse",
    "A5_Staffing",
    "A6_Procurement",
    "A7_Fulfilment",
    "A8_Transport",
]

# Execution is deliberately not a simple A1->...->A8 pipeline.  A8 can inform
# procurement and fulfilment about route constraints; A6 then integrates demand,
# supplier, inventory and transport evidence.
AGENT_EXECUTION_ORDER = [
    "A1_Demand", "A2_Supplier", "A3_Inventory", "A4_Warehouse",
    "A5_Staffing", "A8_Transport", "A6_Procurement", "A7_Fulfilment",
]

@dataclass
class SemanticEvent:
    event_type: str
    target: str
    text: str
    severity: float
    confidence: float
    expires_in: int = 2
    source: str = "operations_feed"
    age: int = 0

@dataclass
class InboundOrder:
    supplier: str
    qty: float
    arrival_step: int
    delayed: bool = False

@dataclass
class WorldState:
    episode: int
    step: int
    phase: str
    scenario: str
    scenario_variant: str

    inventory: float
    backlog: float
    urgent_backlog: float
    current_demand: float
    current_urgent_demand: float
    demand_forecast: float

    supplier_a_risk: float
    supplier_b_risk: float
    supplier_a_lead: int
    supplier_b_lead: int
    route_a_risk: float
    route_b_risk: float

    staff_available: int
    base_staff: int
    throughput_per_worker: float
    forklift_available: bool
    transport_capacity: float
    decision_budget_units: float

    incoming: list[InboundOrder] = field(default_factory=list)
    semantic_events: list[SemanticEvent] = field(default_factory=list)
    history: list[dict[str, Any]] = field(default_factory=list)

    # Hidden simulation variables. They affect specialist outputs but are not
    # included in compact/full World Model views, preventing evaluation leakage.
    latent_agent_bias: dict[str, float] = field(default_factory=dict, repr=False)

    def compact(self) -> dict[str, Any]:
        return {
            "episode": self.episode,
            "step": self.step,
            "phase": self.phase,
            "scenario": self.scenario,
            "scenario_variant": self.scenario_variant,
            "inventory": round(self.inventory, 2),
            "backlog": round(self.backlog, 2),
            "urgent_backlog": round(self.urgent_backlog, 2),
            "current_demand": round(self.current_demand, 2),
            "current_urgent_demand": round(self.current_urgent_demand, 2),
            "demand_forecast": round(self.demand_forecast, 2),
            "supplier_a_risk": round(self.supplier_a_risk, 3),
            "supplier_b_risk": round(self.supplier_b_risk, 3),
            "supplier_a_lead": self.supplier_a_lead,
            "supplier_b_lead": self.supplier_b_lead,
            "route_a_risk": round(self.route_a_risk, 3),
            "route_b_risk": round(self.route_b_risk, 3),
            "staff_available": self.staff_available,
            "base_staff": self.base_staff,
            "throughput_per_worker": self.throughput_per_worker,
            "forklift_available": self.forklift_available,
            "transport_capacity": round(self.transport_capacity, 2),
            "decision_budget_units": round(self.decision_budget_units, 2),
            "incoming": [asdict(x) for x in self.incoming],
            "semantic_events": [asdict(x) for x in self.semantic_events],
            "recent_history": self.history[-4:],
        }

@dataclass
class AgentMessage:
    agent: str
    confidence: float
    evidence: dict[str, Any]
    proposal: dict[str, Any] = field(default_factory=dict)
    requests: list[str] = field(default_factory=list)
    shell_used: bool = False
    shell_input_tokens: int = 0
    shell_output_tokens: int = 0
    shell_latency_ms: float = 0.0
    shell_fallback: bool = False

@dataclass
class ActionPlan:
    order_qty: int = 0
    supplier: str = "A"
    overtime_workers: int = 0
    urgent_priority: float = 0.70
    expedite_transport: bool = False
    rent_forklift: bool = False
    confidence: float = 0.70
    rationale: str = ""

    def clamp(self) -> "ActionPlan":
        self.order_qty = int(max(0, min(340, round(self.order_qty))))
        self.supplier = "B" if str(self.supplier).upper() == "B" else "A"
        self.overtime_workers = int(max(0, min(5, round(self.overtime_workers))))
        self.urgent_priority = float(max(0.0, min(1.0, self.urgent_priority)))
        self.expedite_transport = bool(self.expedite_transport)
        self.rent_forklift = bool(self.rent_forklift)
        self.confidence = float(max(0.0, min(1.0, self.confidence)))
        return self
