from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Iterable

@dataclass
class ExperienceCapsule:
    episode: int
    phase: str
    scenario: str
    signature: tuple[str, ...]
    agents: tuple[str, ...]
    useful_agents: tuple[str, ...]
    level: int
    reward: float
    operational_score: float
    resource_cost: float
    success: int
    final_backlog: float
    mean_order_ratio: float
    mean_overtime: float
    mean_urgent_priority: float
    expedite_rate: float
    supplier_b_rate: float

class ExperienceMemory:
    """Compact causal experience memory; no embeddings and no raw-dialogue replay."""

    def __init__(self, max_items: int = 400):
        self.max_items = max_items
        self.items: list[ExperienceCapsule] = []

    @staticmethod
    def _tokens(signature: Iterable[str]) -> set[str]:
        return {x for x in signature if not str(x).startswith("phase:")}

    @classmethod
    def similarity(cls, a: Iterable[str], b: Iterable[str]) -> float:
        aa, bb = cls._tokens(a), cls._tokens(b)
        if not aa and not bb:
            return 1.0
        if not aa or not bb:
            return 0.0
        union, inter = aa | bb, aa & bb
        def weight(tok: str) -> float:
            return .50 if ":" in tok else 1.0
        return sum(weight(t) for t in inter) / max(sum(weight(t) for t in union), 1e-9)

    def add(self, capsule: ExperienceCapsule):
        self.items.append(capsule)
        if len(self.items) > self.max_items:
            self.items = self.items[-self.max_items:]

    def retrieve(self, signature: Iterable[str], top_k: int = 4, threshold: float = .46, scenario: str | None = None):
        scored = []
        for item in self.items:
            sim = self.similarity(signature, item.signature)
            if scenario and item.scenario == scenario:
                sim = min(1.0, sim + .10)
            if sim >= threshold:
                scored.append((sim, item))
        scored.sort(key=lambda x: (x[0], x[1].operational_score, x[1].reward), reverse=True)
        return scored[:top_k]

    def guidance(self, signature: Iterable[str], scenario: str | None = None) -> dict:
        retrieved = self.retrieve(signature, scenario=scenario)
        agent_bias: dict[str, float] = {}
        level_bias = {1: 0.0, 2: 0.0, 3: 0.0}
        action_acc = {
            "mean_order_ratio": 0.0,
            "mean_overtime": 0.0,
            "mean_urgent_priority": 0.0,
            "expedite_rate": 0.0,
            "supplier_b_rate": 0.0,
        }
        total_w = 0.0
        if not retrieved:
            return {
                "retrieved": [], "agent_bias": agent_bias, "level_bias": level_bias,
                "action_hint": {}, "max_similarity": 0.0, "mean_similarity": 0.0,
            }

        for sim, cap in retrieved:
            # Only reasonably good prior episodes provide positive guidance.
            quality = max(0.0, min(1.0, (cap.operational_score - 54.0) / 28.0))
            quality *= (.85 + .15 * cap.success)
            if quality <= 0:
                continue
            w = sim * quality
            for a in cap.useful_agents or cap.agents:
                agent_bias[a] = agent_bias.get(a, 0.0) + w * .22
            # A successful low-level solution is valuable evidence that escalation
            # is unnecessary; higher levels are reused only when they actually worked.
            level_bias[cap.level] += w * (.24 if cap.level == 1 else (.11 if cap.level == 2 else .05))
            if cap.operational_score >= 65.0 and cap.final_backlog <= 105.0:
                for k in action_acc:
                    action_acc[k] += w * float(getattr(cap, k))
                total_w += w

        action_hint = {k: v / total_w for k, v in action_acc.items()} if total_w > 0 else {}
        return {
            "retrieved": retrieved,
            "agent_bias": agent_bias,
            "level_bias": level_bias,
            "action_hint": action_hint,
            "max_similarity": max(x[0] for x in retrieved),
            "mean_similarity": sum(x[0] for x in retrieved) / len(retrieved),
        }

    @staticmethod
    def reuse_is_useful(retrieved, current_relevant_agents: set[str]) -> bool | None:
        if not retrieved:
            return None
        sim, cap = retrieved[0]
        preferred = set(cap.useful_agents or cap.agents)
        if not preferred:
            return False
        precision = len(preferred & current_relevant_agents) / len(preferred)
        return bool(sim >= .46 and precision >= .60 and cap.operational_score >= 58.0)

    def rows(self):
        rows = []
        for c in self.items:
            d = asdict(c)
            d["signature"] = ";".join(c.signature)
            d["agents"] = ";".join(c.agents)
            d["useful_agents"] = ";".join(c.useful_agents)
            rows.append(d)
        return rows
