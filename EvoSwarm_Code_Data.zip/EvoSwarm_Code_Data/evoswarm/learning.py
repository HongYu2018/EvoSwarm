from __future__ import annotations
import random
from collections import defaultdict
from itertools import combinations
from .core import AGENTS
from .world_model import FEATURE_AGENT_MAP

class ContextualAgentTrust:
    """Learns agent reliability by operational context rather than one global score."""

    def __init__(self, alpha=.045, initial=.72):
        self.alpha = alpha
        self.initial = initial
        self.values = defaultdict(lambda: initial)

    def score(self, agent: str, features) -> float:
        vals = [self.values[(f, agent)] for f in features]
        return sum(vals) / max(len(vals), 1)

    def update(self, features, agent: str, outcome_signal: float, contribution: float = 1.0):
        # outcome_signal in [-1,1]. contribution prevents unused evidence from
        # receiving the same credit as evidence that affected a downstream action.
        target = max(.08, min(.96, .55 + .40 * outcome_signal * max(.15, contribution)))
        for f in features:
            k = (f, agent)
            old = self.values[k]
            self.values[k] = (1 - self.alpha) * old + self.alpha * target

    def rows(self):
        return [
            {"feature": f, "agent": a, "trust": v}
            for (f, a), v in sorted(self.values.items())
        ]

class CausalCapabilityGraph:
    """Evolving feature->agent and agent<->agent usefulness graph."""

    def __init__(self, alpha=.04):
        self.alpha = alpha
        self.feature_agent = defaultdict(float)
        self.agent_pair = defaultdict(float)
        for f, agents in FEATURE_AGENT_MAP.items():
            for a in agents:
                self.feature_agent[(f, a)] = .20

    def agent_score(self, agent, features):
        return sum(self.feature_agent[(f, agent)] for f in features) / max(len(features), 1)

    def pair_score(self, a, b, features):
        p = tuple(sorted((a, b)))
        vals = [self.agent_pair[(f, p)] for f in features]
        return sum(vals) / max(len(vals), 1)

    def update(self, features, selected, signal, credits, communication_edges=None):
        """Update capability and collaboration weights.

        Agent-pair weights now represent *realised evidence flow* rather than mere
        co-presence. This makes the pair graph a communication-topology signal: a
        pair receives strong credit only when one agent actually used the other's
        evidence during the current decision.
        """
        communication_edges = communication_edges or set()
        comm_pairs = {tuple(sorted(edge)) for edge in communication_edges}
        for f in features:
            for a in selected:
                credit = credits.get(a, .25)
                k = (f, a)
                target = signal * credit
                self.feature_agent[k] = max(-.35, min(.70,
                    (1 - self.alpha) * self.feature_agent[k] + self.alpha * target
                ))
            for a, b in combinations(sorted(selected), 2):
                p = (a, b)
                k = (f, p)
                if p in comm_pairs:
                    credit = min(credits.get(a, .25), credits.get(b, .25))
                    target = signal * credit
                    rate = self.alpha
                else:
                    # Co-presence without evidence exchange should not be learned
                    # as a useful communication edge. Gently decay toward zero.
                    target = 0.0
                    rate = .18 * self.alpha
                self.agent_pair[k] = max(-.25, min(.45,
                    (1 - rate) * self.agent_pair[k] + rate * target
                ))

    def rows(self):
        return [
            {"feature": f, "agent": a, "weight": w}
            for (f, a), w in sorted(self.feature_agent.items())
        ]

    def pair_rows(self):
        return [
            {"feature": f, "agent_a": p[0], "agent_b": p[1], "weight": w}
            for (f, p), w in sorted(self.agent_pair.items())
        ]

class MinimumSufficientTopologyQLambda:
    """
    Factorised topology learner whose target is sufficient causal coverage with
    resource-aware expansion/contraction. Mandatory causal coverage is protected;
    optional support agents and communication links must show positive learned
    marginal value after a topology-complexity penalty.
    """

    # Directed evidence flows that the current specialist implementations can use.
    # Context-essential links are protected; the remaining links are optional and
    # must earn their place from learned pair utility / experience.
    KNOWN_FLOWS = {
        ("A1_Demand", "A3_Inventory"): {"demand_pressure", "inventory_risk", "regime_shift", "stable"},
        ("A1_Demand", "A6_Procurement"): {"demand_pressure", "inventory_risk", "regime_shift", "stable"},
        ("A2_Supplier", "A6_Procurement"): {"supplier_risk", "evidence_conflict"},
        ("A3_Inventory", "A6_Procurement"): {"inventory_risk", "demand_pressure", "backlog_pressure"},
        ("A8_Transport", "A6_Procurement"): {"transport_constraint", "deadline_pressure"},
        ("A4_Warehouse", "A5_Staffing"): {"staff_shortage", "warehouse_constraint", "backlog_pressure"},
        ("A3_Inventory", "A7_Fulfilment"): {"inventory_risk", "urgent_pressure", "deadline_pressure"},
        ("A4_Warehouse", "A7_Fulfilment"): {"warehouse_constraint", "staff_shortage", "backlog_pressure", "deadline_pressure"},
        ("A8_Transport", "A7_Fulfilment"): {"transport_constraint", "urgent_pressure", "deadline_pressure"},
    }

    def __init__(self, seed=7, alpha=.10, gamma=.84, lam=.74,
                 epsilon=.18, epsilon_decay=.994, min_epsilon=.025):
        self.rng = random.Random(seed)
        self.alpha = alpha
        self.gamma = gamma
        self.lam = lam
        self.epsilon = epsilon
        self.epsilon_decay = epsilon_decay
        self.min_epsilon = min_epsilon
        self.q_agent = defaultdict(float)
        self.q_pair = defaultdict(float)
        self.e_agent = defaultdict(float)
        self.e_pair = defaultdict(float)
        # Fixed regularisers: these are topology-complexity penalties, not tuned
        # against a particular baseline result. They simply require optional
        # structure to have a positive expected marginal contribution.
        self.support_agent_penalty = .055
        self.support_edge_penalty = .012
        self.optional_edge_penalty = .018
        self.last_support_added = 0
        self.last_support_pruned = 0
        self.last_predicted_edges = set()
        self.last_protected_edges = set()
        self.prior = {
            "demand_pressure": {"A1_Demand": .20, "A3_Inventory": .10, "A6_Procurement": .12},
            "supplier_risk": {"A2_Supplier": .20, "A6_Procurement": .14, "A3_Inventory": .08},
            "inventory_risk": {"A3_Inventory": .20, "A6_Procurement": .16, "A7_Fulfilment": .07},
            "backlog_pressure": {"A4_Warehouse": .16, "A5_Staffing": .16, "A7_Fulfilment": .14, "A8_Transport": .08},
            "staff_shortage": {"A5_Staffing": .20, "A4_Warehouse": .16, "A7_Fulfilment": .07},
            "warehouse_constraint": {"A4_Warehouse": .20, "A5_Staffing": .15, "A7_Fulfilment": .07},
            "urgent_pressure": {"A7_Fulfilment": .20, "A8_Transport": .15, "A3_Inventory": .07},
            "transport_constraint": {"A8_Transport": .20, "A6_Procurement": .10, "A7_Fulfilment": .12},
            "deadline_pressure": {"A7_Fulfilment": .18, "A8_Transport": .18, "A4_Warehouse": .08},
            "evidence_conflict": {"A2_Supplier": .13, "A6_Procurement": .15, "A7_Fulfilment": .05},
            "regime_shift": {"A1_Demand": .18, "A3_Inventory": .10, "A6_Procurement": .12},
            "stable": {"A1_Demand": .12, "A3_Inventory": .09, "A6_Procurement": .11},
        }

    def _base_score(self, a, features, trust, graph, experience_bias):
        q = sum(max(-.22, min(.25, self.q_agent[(f, a)])) for f in features)
        prior = sum(self.prior.get(f, {}).get(a, 0.0) for f in features)
        trust_bonus = .24 * (trust.score(a, features) - .50)
        graph_bonus = .35 * graph.agent_score(a, features)
        exp_bonus = experience_bias.get(a, 0.0)
        return q + prior + trust_bonus + graph_bonus + exp_bonus

    def _agent_learned_score(self, a, features):
        vals = [max(-.10, min(.14, self.q_agent[(f, a)])) for f in features]
        return sum(vals) / max(len(vals), 1)

    def _pair_score(self, a, b, features, graph):
        p = tuple(sorted((a, b)))
        q = sum(max(-.12, min(.15, self.q_pair[(f, p)])) for f in features)
        return q + .30 * graph.pair_score(a, b, features)

    def _pair_score_mean(self, a, b, features, graph):
        # Marginal topology decisions use a context-normalised pair value so a
        # situation does not look more valuable merely because more feature labels
        # are active. Stage-1 causal selection may still use the summed score.
        return self._pair_score(a, b, features, graph) / max(len(features), 1)

    @staticmethod
    def coverage(selected: set[str], requirements: dict[str, set[str]]) -> float:
        if not requirements:
            return 1.0
        covered = sum(1 for agents in requirements.values() if selected & agents)
        return covered / len(requirements)

    def _support_margin(self, a, selected, features, trust, graph, experience_bias):
        pair_values = [self._pair_score_mean(a, b, features, graph) for b in selected if b != a]
        positive_pair = sum(max(0.0, v) for v in pair_values)
        negative_pair = sum(min(0.0, v) for v in pair_values)
        expected_edges = sum(1 for v in pair_values if v > .020)
        exp = max(0.0, min(.18, experience_bias.get(a, 0.0)))
        learned = max(-.08, min(.12, self._agent_learned_score(a, features)))
        trust_term = max(-.08, min(.08, trust.score(a, features) - .55))

        # Experience is corroborating evidence, not sufficient evidence by itself.
        # This prevents memory retrieval from monotonically expanding the swarm:
        # an optional agent must first have learned capability or communication
        # value in the current context before analogous experience can strengthen it.
        has_learned_support = positive_pair > .020 or learned > .025
        exp_term = .34 * exp if has_learned_support else 0.0
        expected_gain = (
            .82 * positive_pair + .28 * negative_pair
            + exp_term + .28 * max(0.0, learned) + .16 * trust_term
        )
        complexity_cost = self.support_agent_penalty + self.support_edge_penalty * expected_edges
        return expected_gain - complexity_cost

    def select(self, features, requirements, trust, graph, experience_bias=None,
               min_agents=3, max_agents=7):
        """Coverage first, then marginal-utility expansion and contraction.

        Stage 1 forms a causally sufficient core. Stage 2 can add support agents
        only when learned/experience evidence predicts a positive marginal gain
        after topology cost. Stage 3 removes optional support whose marginal value
        becomes non-positive once the complete candidate swarm is considered.
        """
        experience_bias = experience_bias or {}
        complexity = len(requirements)
        target = .90 if complexity <= 3 else (.94 if complexity <= 5 else .97)
        if "evidence_conflict" in features or "deadline_pressure" in features:
            target = max(target, .94)

        selected: list[str] = []
        remaining = set(AGENTS)
        exploratory = self.rng.random() < self.epsilon

        # ---- Stage 1: causally sufficient core ----
        while remaining and len(selected) < max_agents:
            current_cov = self.coverage(set(selected), requirements)
            if len(selected) >= min_agents and current_cov >= target:
                break

            candidate_rows = []
            for a in remaining:
                new = set(selected) | {a}
                marginal_cov = max(0.0, self.coverage(new, requirements) - current_cov)
                candidate_rows.append((a, marginal_cov))

            if current_cov < target and any(mc > 0 for _, mc in candidate_rows):
                positive = [(a, mc) for a, mc in candidate_rows if mc > 0]
                # Causal sufficiency is lexicographically prior to learned
                # preference: first close as many currently missing causal roles
                # as possible, then use learned value/trust to break the tie.
                # This prevents experience from preferring a familiar but narrow
                # agent that requires extra agents later merely to recover coverage.
                best_cov = max(mc for _, mc in positive)
                candidate_rows = [(a, mc) for a, mc in positive if abs(mc - best_cov) < 1e-12]

            best, best_score = None, -1e9
            for a, marginal_cov in candidate_rows:
                score = self._base_score(a, features, trust, graph, experience_bias)
                score += 2.60 * marginal_cov
                score += sum(self._pair_score(a, b, features, graph) for b in selected)
                if exploratory:
                    score += self.rng.uniform(-.08, .08)
                if score > best_score:
                    best, best_score = a, score

            if best is None:
                break
            selected.append(best)
            remaining.remove(best)

        core = set(selected)

        # ---- Stage 2: positive-marginal support expansion ----
        support_budget = 0
        if complexity >= 4:
            support_budget = 1
        if complexity >= 7:
            support_budget = 2
        if "evidence_conflict" in features:
            support_budget = max(support_budget, 1)
        support_budget = min(support_budget, max(0, max_agents - len(selected)))

        added = []
        for _ in range(support_budget):
            best, best_margin = None, -1e9
            for a in remaining:
                margin = self._support_margin(a, set(selected), features, trust, graph, experience_bias)
                if exploratory:
                    margin += self.rng.uniform(-.015, .025)
                if margin > best_margin:
                    best, best_margin = a, margin
            if best is None or best_margin <= 0.0:
                break
            selected.append(best)
            added.append(best)
            remaining.remove(best)

        # ---- Stage 3: contraction of any redundant structure ----
        # Re-test every selected agent, not only newly added support. An agent is
        # protected whenever removing it would violate causal coverage/minimum team
        # size. Otherwise it must justify itself by positive learned marginal value.
        # This lets a topology shrink after learning that overlapping capabilities
        # or communication routes make a participant redundant.
        pruned = []
        changed = True
        while changed:
            changed = False
            removable = []
            for a in list(selected):
                others = set(selected) - {a}
                if len(others) < min_agents or self.coverage(others, requirements) < target:
                    continue
                margin = self._support_margin(a, others, features, trust, graph, experience_bias)
                removable.append((margin, a))
            if removable:
                margin, a = min(removable, key=lambda x: x[0])
                if margin <= 0.0:
                    selected.remove(a)
                    remaining.add(a)
                    pruned.append(a)
                    changed = True

        self.last_support_added = len(added)
        self.last_support_pruned = len(pruned)
        self.epsilon = max(self.min_epsilon, self.epsilon * self.epsilon_decay)
        return set(selected), target

    def communication_policy(self, selected, features, graph, experience_bias=None):
        """Return directed evidence links allowed for this context.

        Context-essential links are always protected. Other usable links are kept
        only when their learned pair value exceeds a fixed edge-complexity penalty.
        Runtime REQUEST_AGENT messages can still reopen a pruned edge when an agent
        discovers that it needs that evidence in the current decision.
        """
        selected = set(selected)
        feature_set = set(features)
        experience_bias = experience_bias or {}
        allowed = set()
        protected = set()
        for (src, dst), triggers in self.KNOWN_FLOWS.items():
            if src not in selected or dst not in selected:
                continue
            if feature_set & triggers:
                allowed.add((src, dst))
                protected.add((src, dst))
                continue
            pair_value = self._pair_score_mean(src, dst, features, graph)
            exp_support = .08 * min(.20, experience_bias.get(src, 0.0) + experience_bias.get(dst, 0.0))
            if pair_value + exp_support - self.optional_edge_penalty > 0.0:
                allowed.add((src, dst))

        self.last_predicted_edges = set(allowed)
        self.last_protected_edges = set(protected)
        return allowed

    def update(self, features, selected, reward, credits=None, communication_edges=None):
        decay = self.gamma * self.lam
        for k in list(self.e_agent):
            self.e_agent[k] *= decay
            if self.e_agent[k] < 1e-4:
                del self.e_agent[k]
        for k in list(self.e_pair):
            self.e_pair[k] *= decay
            if self.e_pair[k] < 1e-4:
                del self.e_pair[k]

        credits = credits or {a: 1.0 for a in selected}
        communication_edges = communication_edges or set()
        comm_pairs = {tuple(sorted(e)) for e in communication_edges if e[0] in selected and e[1] in selected}
        for f in features:
            for a in selected:
                self.e_agent[(f, a)] += credits.get(a, .35)
            # Pair eligibility is now earned by realised evidence flow, not mere
            # co-presence. This is what lets communication links strengthen/decay.
            for p in comm_pairs:
                a, b = p
                self.e_pair[(f, p)] += min(credits.get(a, .35), credits.get(b, .35))

        vals = [self.q_agent[(f, a)] for f in features for a in selected]
        predicted = sum(vals) / max(len(vals), 1)
        delta = reward - predicted
        for k, e in list(self.e_agent.items()):
            self.q_agent[k] += self.alpha * delta * e
        for k, e in list(self.e_pair.items()):
            self.q_pair[k] += .45 * self.alpha * delta * e

        # Co-present but unused pair links slowly decay toward zero rather than
        # accumulating credit simply because both agents happened to be active.
        for f in features:
            for a, b in combinations(sorted(selected), 2):
                p = (a, b)
                if p not in comm_pairs:
                    self.q_pair[(f, p)] *= .997

    def retrospective_update(self, transitions, terminal_signal: float):
        # Downstream episode outcomes update earlier agent choices and only the
        # communication links that actually carried evidence.
        discount = 1.0
        for tr in reversed(transitions):
            if len(tr) == 4:
                features, selected, credits, communication_edges = tr
            else:  # backward-compatible with older transition tuples
                features, selected, credits = tr
                communication_edges = set()
            comm_pairs = {tuple(sorted(e)) for e in communication_edges}
            target = terminal_signal * discount
            for f in features:
                for a in selected:
                    self.q_agent[(f, a)] += .025 * target * credits.get(a, .35)
                for a, b in comm_pairs:
                    self.q_pair[(f, (a, b))] += .010 * target * min(credits.get(a, .35), credits.get(b, .35))
            discount *= .83

    def rows(self):
        keys = set(self.q_agent) | {(f, a) for f in self.prior for a in AGENTS}
        return [
            {"feature": f, "agent": a, "q_value": self.q_agent[(f, a)], "prior": self.prior.get(f, {}).get(a, 0.0)}
            for f, a in sorted(keys)
        ]

    def pair_rows(self):
        return [
            {"feature": f, "agent_a": p[0], "agent_b": p[1], "q_value": q}
            for (f, p), q in sorted(self.q_pair.items())
        ]

class AdaptiveLevelQLambda:
    def __init__(self, seed=11, alpha=.10, gamma=.82, lam=.68, epsilon=.15, epsilon_decay=.994):
        self.rng = random.Random(seed)
        self.alpha = alpha
        self.gamma = gamma
        self.lam = lam
        self.epsilon = epsilon
        self.epsilon_decay = epsilon_decay
        self.q = defaultdict(float)
        self.e = defaultdict(float)
        self.prior = {1: .11, 2: .025, 3: -.055}

    def choose(self, features, experience_level_bias=None, trust_floor=.72):
        experience_level_bias = experience_level_bias or {}
        if self.rng.random() < self.epsilon:
            # Safe exploration prefers neighbouring levels over random jumps.
            base = 1 if trust_floor >= .62 else 2
            return self.rng.choice([base, min(3, base + 1)])
        # A high-quality analogous L1/L2 episode acts as evidence that stronger
        # reasoning is unnecessary unless current trust/conflict says otherwise.
        if experience_level_bias.get(1, 0.0) >= .075 and trust_floor >= .55 and "evidence_conflict" not in features:
            self.epsilon = max(.025, self.epsilon * self.epsilon_decay)
            return 1
        if experience_level_bias.get(2, 0.0) >= .075 and trust_floor >= .48 and "evidence_conflict" not in features:
            self.epsilon = max(.025, self.epsilon * self.epsilon_decay)
            return 2
        scores = {}
        for level in [1, 2, 3]:
            scores[level] = self.prior[level] + experience_level_bias.get(level, 0.0) + sum(self.q[(f, level)] for f in features)
        if trust_floor < .48 or "evidence_conflict" in features:
            scores[2] += .06
        if trust_floor < .38 and len(features) >= 4:
            scores[3] += .05
        best = max(scores.values())
        level = min(l for l, v in scores.items() if abs(v - best) < 1e-12)
        # L3 is an exception/critic, not a routine replacement. Learned preference
        # alone cannot invoke it without a hard-context gate.
        hard_l3 = (
            "evidence_conflict" in features
            or (len(features) >= 5 and trust_floor < .62)
            or trust_floor < .42
        )
        if level == 3 and not hard_l3:
            level = 2
        # If high-quality similar experience already solved the context at L1/L2,
        # do not relearn an unnecessary L3 escalation.
        if level == 3 and max(experience_level_bias.get(1, 0.0), experience_level_bias.get(2, 0.0)) >= .08:
            level = 1 if experience_level_bias.get(1, 0.0) >= experience_level_bias.get(2, 0.0) else 2
        self.epsilon = max(.025, self.epsilon * self.epsilon_decay)
        return level

    def update(self, features, level, reward):
        decay = self.gamma * self.lam
        for k in list(self.e):
            self.e[k] *= decay
            if self.e[k] < 1e-4:
                del self.e[k]
        for f in features:
            self.e[(f, level)] += 1.0
        predicted = sum(self.q[(f, level)] for f in features) / max(len(features), 1)
        delta = reward - predicted
        for k, e in list(self.e.items()):
            self.q[k] += self.alpha * delta * e

    def retrospective_update(self, transitions, terminal_signal):
        discount = 1.0
        for features, level in reversed(transitions):
            for f in features:
                self.q[(f, level)] += .018 * terminal_signal * discount
            discount *= .83

    def rows(self):
        return [
            {"feature": f, "level": l, "q_value": self.q[(f, l)], "prior": self.prior[l]}
            for f, l in sorted(self.q)
        ]
