from pathlib import Path
import matplotlib.pyplot as plt


def create_plots(summary, scenario_summary, step_results, out):
    out = Path(out)
    d = summary.sort_values("mean_operational_score", ascending=False)
    plt.figure(figsize=(11, 5.8))
    plt.bar(d.system, d.mean_operational_score)
    plt.ylabel("Mean operational score (0-100)")
    plt.xticks(rotation=25, ha="right")
    plt.title("EvoSwarm V1.4: Operational Performance")
    plt.tight_layout()
    plt.savefig(out / "operational_score.png", dpi=180)
    plt.close()

    p = scenario_summary.pivot(index="scenario", columns="system", values="operational_score")
    p.plot(kind="bar", figsize=(13, 6.5))
    plt.ylabel("Operational score")
    plt.title("Performance by Dynamic Scenario Family")
    plt.xticks(rotation=25, ha="right")
    plt.tight_layout()
    plt.savefig(out / "scenario_performance.png", dpi=180)
    plt.close()

    j = step_results[step_results.system == "joint_evoswarm"]
    if not j.empty:
        r = j.active_agent_count.rolling(12, min_periods=1).mean()
        c = j.causal_coverage.rolling(12, min_periods=1).mean()
        plt.figure(figsize=(10, 5))
        plt.plot(range(len(r)), r)
        plt.ylabel("Rolling active specialists")
        plt.xlabel("Decision cycle")
        plt.title("Experienced Joint EvoSwarm: Dynamic Swarm Size")
        plt.tight_layout()
        plt.savefig(out / "joint_swarm_size.png", dpi=180)
        plt.close()

        plt.figure(figsize=(10, 5))
        plt.plot(range(len(c)), c)
        plt.ylim(0, 1.05)
        plt.ylabel("Rolling causal coverage")
        plt.xlabel("Decision cycle")
        plt.title("Experienced Joint EvoSwarm: Causal Coverage")
        plt.tight_layout()
        plt.savefig(out / "joint_causal_coverage.png", dpi=180)
        plt.close()
