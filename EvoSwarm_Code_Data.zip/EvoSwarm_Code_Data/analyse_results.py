from __future__ import annotations
import argparse
from pathlib import Path
import pandas as pd


def _fmt(df):
    return df.to_string(index=False)


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--output-dir", default="outputs")
    a = p.parse_args()
    r = Path(a.output_dir)

    summary = pd.read_csv(r / "summary.csv")
    scenarios = pd.read_csv(r / "scenario_summary.csv")
    phases = pd.read_csv(r / "phase_summary.csv")
    self_evo = pd.read_csv(r / "self_evolution_summary.csv") if (r / "self_evolution_summary.csv").exists() else pd.DataFrame()

    print("\nOVERALL")
    print(_fmt(summary))

    print("\nPHASES")
    print(_fmt(phases))

    if not self_evo.empty:
        print("\nSELF-EVOLUTION: EXPERIENCED VS COLD JOINT SWARM")
        print(_fmt(self_evo))

    for name in scenarios.scenario.unique():
        d = scenarios[scenarios.scenario == name].sort_values("operational_score", ascending=False)
        print(f"\n--- {name} ---")
        cols = ["system", "n", "success", "service", "urgent_service", "operational_score", "backlog", "deadline_miss_rate", "active_agents", "agent_recall", "causal_coverage", "l3_calls"]
        print(_fmt(d[cols]))

    if {"joint_evoswarm", "pure_l3"} <= set(summary.system):
        x = summary.set_index("system")
        j, q = x.loc["joint_evoswarm"], x.loc["pure_l3"]
        print("\nJOINT EVOSWARM VS PURE L3")
        print(f"Operational score: {j.mean_operational_score:.2f} vs {q.mean_operational_score:.2f}")
        print(f"Service:           {j.service_level:.3f} vs {q.service_level:.3f}")
        print(f"Success:           {j.scenario_success_rate:.3f} vs {q.scenario_success_rate:.3f}")
        print(f"L3 calls/episode:  {j.l3_calls:.2f} vs {q.l3_calls:.2f}")
        print(f"Input tokens:      {int(j.input_tokens)} vs {int(q.input_tokens)}")

    if {"fixed_hybrid", "vertical_evoswarm"} <= set(summary.system):
        x = summary.set_index("system")
        f, v = x.loc["fixed_hybrid"], x.loc["vertical_evoswarm"]
        print("\nFIXED HYBRID VS VERTICAL EVOSWARM")
        print(f"Operational score: {f.mean_operational_score:.2f} vs {v.mean_operational_score:.2f}")
        print(f"L2 calls/episode:  {f.l2_calls:.2f} vs {v.l2_calls:.2f}")
        print(f"L3 calls/episode:  {f.l3_calls:.2f} vs {v.l3_calls:.2f}")
        print(f"Total tokens:      {int(f.input_tokens+f.output_tokens)} vs {int(v.input_tokens+v.output_tokens)}")

if __name__ == "__main__":
    main()
