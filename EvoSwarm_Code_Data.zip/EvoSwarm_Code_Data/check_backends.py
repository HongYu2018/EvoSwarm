import json,urllib.request
from evoswarm.config import Settings
def main():
    s=Settings();print("Ollama model:",s.ollama_model);payload={"model":s.ollama_model,"prompt":'Return JSON only: {"status":"ok"}',"stream":False,"format":"json"};req=urllib.request.Request(s.ollama_url,data=json.dumps(payload).encode(),headers={"Content-Type":"application/json"},method="POST")
    try:
        with urllib.request.urlopen(req,timeout=60) as r:print("Ollama OK:",json.loads(r.read().decode()).get("response",""))
    except Exception as e:print("Ollama FAILED:",repr(e))
    print("OpenAI EvoSwarm L3:",s.openai_l3_model);print("OpenAI pure L3:",s.pure_l3_model)
    if not s.openai_api_key:return print("OpenAI: OPENAI_API_KEY not set")
    try:
        from openai import OpenAI;c=OpenAI(api_key=s.openai_api_key);r=c.responses.create(model=s.pure_l3_model,input="Reply with OK.",store=False);print("OpenAI OK:",r.output_text.strip())
    except Exception as e:print("OpenAI FAILED:",repr(e))
if __name__=="__main__":main()
