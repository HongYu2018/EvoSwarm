# EvoSwarm Supply-Chain V1.4

V1.4 is the first version designed explicitly around the research claim:

> **Effective swarm intelligence is not merely selecting fewer agents. It is learning the minimum sufficient causal capability set, assigning delayed credit to downstream outcomes, and reusing experience so similar future situations can be solved with equal or better operational quality and lower intelligence expenditure.**

## What changed from V1.3

### 1. World Model = state + time + causality + uncertainty
The World Model now represents:
- current demand, inventory, supplier, warehouse, staffing and transport state;
- delayed inbound inventory and recent history;
- semantic events with source, confidence and age;
- causal closure (e.g. supplier risk -> inventory risk -> urgent fulfilment risk);
- workload-dependent warehouse/transport constraints;
- decision-time budgets for genuinely time-critical cases;
- no-action downstream consequence estimates.

### 2. Dynamic scenarios no longer assume a fixed pipeline
V1.4 includes:
- normal replenishment;
- supplier disruption followed by recovery;
- staff shortage followed by shift recovery;
- promotion + capacity pressure;
- conflicting supplier and transport evidence;
- precautionary supplier false alarm followed by a real staffing problem;
- time-critical dispatch;
- three novel compound generalisation scenarios.

Some specialist models are contextually biased/degraded in selected regimes. These latent biases are **not exposed to the World Model**, allowing contextual trust to be learned from evidence accuracy.

### 3. Minimum sufficient swarm
Joint EvoSwarm no longer has a hard objective to minimise agent count.

For each context, the topology policy estimates causal capability requirements such as:
- supplier assessment;
- procurement response;
- warehouse-capacity assessment;
- staff scheduling;
- fulfilment prioritisation;
- transport assessment.

The swarm is allowed to grow up to all eight specialists when the causal situation requires them.

### 4. Runtime reconfiguration
An agent can request a missing capability during the same decision cycle. Requested agents are executed immediately and integrating agents can be re-run so new evidence changes the current action.

### 5. Contextual agent trust
Trust is learned per context from observable evidence accuracy, not from whole-episode success.
Examples:
- demand forecast error updates A1 trust;
- supplier-risk calibration updates A2 trust;
- inventory-risk calibration updates A3 trust;
- warehouse-capacity accuracy updates A4 trust;
- route-risk calibration updates A8 trust.

### 6. Temporal credit
Topology and intelligence-level policies use eligibility traces **plus episode-end retrospective updates**, so downstream backlog or stockout outcomes can update earlier decisions.

### 7. Causal capability graph
V1.4 maintains an evolving graph of:
- feature -> agent usefulness;
- agent-pair synergy.

This is separate from contextual trust and the topology Q-values.

### 8. Experience memory and self-evolution
Each completed experienced-Joint episode becomes a compact causal experience capsule containing:
- causal/context signature;
- swarm used;
- useful agents;
- dominant intelligence level;
- operational outcome;
- resource cost;
- action profile for analysis.

Similarity is symbolic/causal, not embedding similarity.

The experiment has three phases:
1. **Experience** — learn from initial scenarios.
2. **Recurrence** — surface details change but analogous causal structures return.
3. **Generalisation** — novel compound situations combine previously encountered causal factors.

### 9. Cold control
`joint_evoswarm_cold` has the same architecture but resets topology learning, trust, capability graph, level policy and memory every episode.

Therefore:

`joint_evoswarm` vs `joint_evoswarm_cold`

is the main self-evolution comparison.

## Systems compared

| System | Specialist team | Topology | L2/L3 | Cross-episode evolution |
|---|---|---|---|---|
| `full_l1_shell` | all 8 | fixed | none | no |
| `fixed_hybrid` | all 8 | fixed | handcrafted escalation | no |
| `vertical_evoswarm` | all 8 | fixed | learned | level policy only |
| `joint_evoswarm_cold` | runtime | adaptive | learned | **reset each episode** |
| `joint_evoswarm` | runtime | adaptive | learned | **yes** |
| `pure_l3` | none | none | GPT directly | no |

Both EvoSwarm's frontier critic and the pure-L3 baseline default to:

`gpt-4.1-mini-2025-04-14`

Pure L3 receives the full World Model directly and receives **no specialist-agent outputs**.

## Success metric

`scenario_success` is deliberately strict and secondary. A scenario succeeds only if the complete episode satisfies:
- episode service level >= 0.85;
- urgent-order service >= 0.90;
- final weighted backlog <= 32;
- decision deadline met on >= 75% of steps;
- no critical constraint violation.

Do **not** rank systems using success rate alone.

Primary operational metrics are continuous:
- service level;
- urgent service;
- operational score (0-100);
- backlog;
- operational cost;
- deadline miss rate.

Swarm metrics:
- active agents;
- agent precision/recall;
- causal capability coverage;
- runtime requests;
- agent executions.

Resource metrics:
- shell/L2/L3 calls;
- tokens;
- latency;
- resource cost;
- decision units.

Self-evolution metrics:
- **Experience Gain** = experienced operational score - cold operational score;
- **Resource Learning Gain** = cold resource cost - experienced resource cost;
- Swarm Reuse Accuracy;
- Adaptation Regret;
- phase-by-phase causal coverage and recall.

## Setup on Windows PowerShell

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
Copy-Item .env.example .env
notepad .env
```

Recommended `.env`:

```text
OLLAMA_URL=http://localhost:11434/api/generate
OLLAMA_MODEL=qwen2.5:7b
OPENAI_API_KEY=your_key_here
OPENAI_L3_MODEL=gpt-4.1-mini-2025-04-14
PURE_L3_MODEL=gpt-4.1-mini-2025-04-14
```

Check backends:

```powershell
python check_backends.py
```

## Recommended experiment sequence

### A. Software smoke test

```powershell
python run_experiment.py --episodes 30 --steps 6 --llm-mode proxy --output-dir outputs_proxy_30
```

Thirty episodes are **not** enough for a strong self-evolution claim: each phase contains only about 10 episodes.

### B. Self-evolution proxy experiment

```powershell
python run_experiment.py --episodes 120 --steps 6 --llm-mode proxy --output-dir outputs_proxy_120
```

This gives approximately 40 experience + 40 recurrence + 40 generalisation episodes.

### C. Multi-seed proxy validation

```powershell
python run_multiseed.py --seeds 7 17 27 37 47 --episodes 60 --steps 6 --llm-mode proxy --output-dir outputs_multiseed
```

### D. Live pilot without pure L3

```powershell
python run_experiment.py --episodes 10 --steps 6 --llm-mode live --output-dir outputs_live_pilot
```

### E. Focused live architecture comparison

```powershell
python run_experiment.py --episodes 10 --steps 6 --llm-mode live --include-pure-l3 --systems fixed_hybrid vertical_evoswarm joint_evoswarm_cold joint_evoswarm pure_l3 --output-dir outputs_live_compare
```

Pure L3 makes one OpenAI call per time step: 10 episodes x 6 steps = 60 pure-L3 calls.

Analyse an output folder:

```powershell
python analyse_results.py --output-dir outputs_live_compare
```

## Key output files

- `summary.csv`
- `scenario_summary.csv`
- `phase_summary.csv`
- `self_evolution_summary.csv`
- `step_results.csv`
- `episode_results.csv`
- `joint_agent_qtable.csv`
- `joint_pair_qtable.csv`
- `joint_level_qtable.csv`
- `contextual_agent_trust.csv`
- `causal_capability_graph.csv`
- `causal_agent_pair_graph.csv`
- `experience_memory.csv`
- `run_metadata.json`

## Interpretation principle

The desired result is **not** necessarily:

`Joint EvoSwarm uses the fewest agents.`

The desired result is:

> Joint EvoSwarm activates the capabilities needed by the causal situation, preserves operational performance, learns from downstream consequences, and becomes more selective about unnecessary agents and L2/L3 reasoning when analogous situations recur.
