# V1.4 Validation Notes

## What was validated

- Python syntax/compile checks passed.
- Proxy experiments run end-to-end.
- Dynamic scenario timelines execute.
- Runtime agent requests execute in the same decision cycle.
- Causal capability coverage reaches approximately 1.0 in the validated runs.
- Cold and experienced joint-swarm controls are distinct.
- Experience memory, contextual trust and causal-capability CSVs are produced.
- Pure-L3 proxy baseline runs without specialist agents.

## Five-seed proxy check

Command:

```text
python run_multiseed.py --seeds 7 17 27 37 47 --episodes 60 --steps 6 --llm-mode proxy
```

Selected means across seeds:

| System | Operational score | Active agents | Resource cost |
|---|---:|---:|---:|
| Full L1 Shell | 66.0959 | 8.000 | 3.4632 |
| Vertical EvoSwarm | 66.3783 | 8.000 | 3.5245 |
| Joint EvoSwarm (experienced) | 64.7668 | 6.082 | 2.7084 |
| Joint EvoSwarm (cold) | 64.7431 | 6.084 | 2.8398 |
| Pure L3 proxy | 65.4702 | 0 | 3.0600 |
| Fixed Hybrid | 64.3393 | 8.000 | 7.4853 |

Self-evolution, experienced minus cold:

| Phase | Operational-score gain | Resource learning gain |
|---|---:|---:|
| Experience | +0.0231 | +0.0800 |
| Recurrence | +0.0390 | +0.1700 |
| Generalisation | +0.0091 | +0.1441 |

These values are **proxy-mode protocol validation only**. They are not evidence about actual Ollama or GPT-4.1-mini performance.

The useful qualitative result is that the final design no longer improves Joint EvoSwarm by blindly pruning agents: both cold and experienced joint systems preserve complete causal coverage, while experienced EvoSwarm shows a small positive proxy signal in operational score and resource efficiency in recurrence/generalisation.

## Not yet validated here

- Live Ollama behaviour in V1.4.
- Live `gpt-4.1-mini-2025-04-14` behaviour in V1.4.
- Statistical publication claims.

Run a small live pilot before any long live experiment.
