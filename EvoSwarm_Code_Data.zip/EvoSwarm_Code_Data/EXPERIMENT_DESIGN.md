# EvoSwarm V1.4 Experimental Design

## Main research question

Can a heterogeneous agent swarm use a causal-temporal World Model and accumulated experience to form a **minimum sufficient swarm**, preserve operational performance, and reduce unnecessary intelligence expenditure when analogous and compound situations recur?

## Hypotheses

### H1 — Causal sufficiency over agent minimisation
Joint EvoSwarm should maintain near-complete causal capability coverage while activating fewer agents than the fixed full team in scenarios where not all capabilities are needed.

### H2 — Temporal credit
Delayed outcomes (backlog, stockout, late fulfilment) should update earlier topology and escalation choices through eligibility traces and retrospective episode credit.

### H3 — Contextual trust
When a specialist becomes unreliable in a specific regime, experienced EvoSwarm should down-weight that agent in the affected context without globally discarding it.

### H4 — Experience reuse
When a causally similar situation returns with different surface wording/details, the experienced swarm should retrieve relevant causal experience and reuse a better topology/escalation prior.

### H5 — Self-evolution
Compared with `joint_evoswarm_cold`, experienced `joint_evoswarm` should show one or both of:
- higher operational performance;
- lower intelligence/resource consumption at comparable performance.

### H6 — Complexity advantage
The value of joint swarm organisation should become more visible in dynamic/conflicting/compound scenarios than in normal replenishment.

### H7 — Architecture vs pure L3
Using the same pinned frontier model, Joint EvoSwarm and pure L3 should exhibit measurably different performance/resource trade-offs. The experiment does not assume beforehand that one must win every scenario.

## Three evaluation phases

For N episodes:
- first third: **experience**;
- second third: **recurrence**;
- final third: **generalisation**.

For the main proxy experiment use N=120 so the phases are approximately 40/40/40.

## Fixed Hybrid remains deliberately strong

`fixed_hybrid`:
- activates all eight specialists;
- uses a hand-designed feature-to-L2/L3 escalation rule;
- carries no learned cross-episode memory.

V1.4 does not weaken this baseline. Instead, dynamic scenarios contain changing relevance, conflicting/stale information, agent regime errors and time-critical cases, so “always consult everyone” is no longer structurally guaranteed to be best.

## Operational score

Operational score is independent of AI resource cost:
- 40% service level;
- 27% urgent-order service;
- 20% backlog control;
- 10% operational-cost control;
- 3% decision deadline.

Learning reward adds only a **small** resource term and a stronger causal-coverage penalty. This prevents the learner from trading away required capabilities just to become smaller.

## Self-evolution definition

Self-evolution is operationalised as:

`Experience -> downstream causal credit -> topology/trust/capability/level updates -> better future behaviour`

The evolved state includes:
- topology Q-values;
- contextual agent trust;
- causal capability graph;
- pairwise capability synergy;
- vertical L1/L2/L3 policy;
- experience memory.

## Experience capsule

An experience capsule contains:
- causal/context signature;
- swarm used;
- useful agents;
- dominant intelligence level;
- operational score and success;
- downstream backlog;
- resource cost;
- compact action profile (stored primarily for analysis).

Retrieval uses symbolic causal similarity. Phase labels are excluded from similarity so experience can transfer to recurrence/generalisation.

## Metrics for the paper

Report separately:

1. **Operational** — service, urgent service, operational score, backlog, cost, deadline miss rate.
2. **Swarm quality** — causal coverage, agent recall/precision, active agents, requests/executions.
3. **Intelligence expenditure** — shell/L2/L3 calls, tokens, latency, decision units.
4. **Self-evolution** — Experience Gain, Resource Learning Gain, Swarm Reuse Accuracy, Adaptation Regret.

Do not use the combined learning reward as the headline performance metric.
